<?php
namespace app\index\controller;

use app\index\model\UserModel;
use think\Db;

class Notice extends Initia
{
    //如何赚佣，一张图
    public function index()
    {
    	
        return $this->fetch();
    }
}
