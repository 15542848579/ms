<?php
namespace app\index\controller;

use app\index\model\UserModel;
use app\index\model\LevelModel;
use think\Controller;
use think\Request;
use think\Captcha;
use think\Session;
use app\index\model\SmsModel;
use app\index\model\RlModel;

// 开始session
session_start();

class Login extends Controller
{

    public function index(){
        return $this->fetch();
    }
    //验证
    public function regist(){
    	$request = Request();
    	$yzm = $request->param('yzm');
    	if(!captcha_check($yzm)){
			$this->error('验证码错误');exit();
		};
    	$where['username'] = $request->param('username');
    	$where['password'] = $request->param('password');
    	$list = UserModel::where($where)->find();
    	if (empty($list)) {
    		$this->error('当前用户名密码错误','/index/login/index');exit();
    	}
    	session::set('islogin',$list);
    	$data['ip'] = $request->ip();
		if(UserModel::where("id",$list['id'])->update($data)){
			$this->redirect('index/index/index');
		}else{
            $this->redirect('index/index/index');
        }
    }
        //退出
    public function Logout(){
        //销毁session
        Session::delete('islogin');
        $this->success("退出成功","index/login/index");
    }

    public function zhuce(){
        $mobile = request()->param('mobile');
        $this->assign('mobile',$mobile);
        return $this->fetch();
    }

    public function reg(){
        $request = request();
        if (session::get('phone') != $request->param('mobile')) {
            $this->error('您输入的手机号请保持一致');
        }
        if (session::get('code') != $request->param('code')) {
            $this->error('您输入的验证码不正确');
        }
        $id = UserModel::where('phone',$request->param('tjr'))->field('id,upid')->find();
        $count = UserModel::where('phone',$request->param('mobile'))->count();
        if ($count == 1) {
            $this->error('您的手机已经注册');
        }
        if (empty($id)) {
            $this->error('您需要邀请人才能注册');
        }

        $p = UserModel::where('username',$request->param('username'))->count();
        if ($p) {
            $this->error('您注册的账号已经存在');
        }

        if ($request->param('password') != $request->param('password1')) {
            $this->error("两次密码输入不一致");
        }

        $data['username'] = $request->param('username');
        $data['phone'] = $request->param('mobile');
        $data['password'] = $request->param('password');
        $data['upid'] = $id['id'];
        $data['time']=time();
        $data['level'] = 0;
        $data['ip'] = Request::instance()->ip();
        $data['sy'] = 0;
        $data['tx'] = 0;
        $suc = UserModel::insertGetId($data);
        if ($suc) {
            $rela['uid'] = $id['id'];
            $rela['upid'] = $id['upid'];
            $rela['dwid'] = $suc;
            RlModel::insert($rela);
            UserModel::where('id','=',$id['id'])->setInc('qnum',1);
            $level['uid'] = $suc;
            LevelModel::insert($level);
            LevelModel::where('uid','=',$id['id'])->setInc('y0',1);
            LevelModel::where('uid','=',$id['upid'])->setInc('e0',1);
            $this->redirect('/index/login/index');
        }
    }

    public function sms(){
        $request = request();
        $phone = $request->param('phone');
        import('sms.smsapi', EXTEND_PATH,'.class.php');
        //接口账号
        $uid = 'jyaihl';

        //接口密码
        $pwd = '98e28407f9da5a88cc2c3e91c34c2f41';

        //实例化接口
        $api = new \SmsApi($uid,$pwd);
        session::set('phone',$phone);
        /*
        * 变量模板发送示例
        * 模板内容：您的验证码是：{$code}，对用户{$username}操作绑定手机号，有效期为5分钟。如非本人操作，可不用理会。【云信】
        * 变量模板ID：100003
        */
        //发送的手机 多个号码用,英文逗号隔开

        $mobile = $phone;
        $code = rand(1000,9999);
        session::set('code',$code);
        //短信内容参数
        $contentParam = array(
            'code'      => $code
            );

        //变量模板ID
        $template = '486687';

        //发送变量模板短信
        $result = $api->send($mobile,$contentParam,$template);

        if($result['stat']=='100')
        {
            $data['mobile'] = $phone;
            $data['time'] = time();
            $data['code'] = $code;
            $end = SmsModel::insert($data);
            return json([
                        'msg' => 200,
                        'message' => '发送成功'
                    ]);
        }else{
            return json([
                    'msg' => 400,
                    'message' => $result['stat'].'('.$result['message'].')'
                ]);
        }
    }

    public function wangji()
    {
        return $this->fetch();
    }

    public function dowangji(){
        $request = request();
        if (session::get('phone') != $request->param('mobile')) {
            $this->error('您输入的手机号请保持一致');
        }
        if (session::get('code') != $request->param('code')) {
            $this->error('您输入的验证码不正确');
        }
        UserModel::where('phone','=',$request()->param('mobile'))->setfield('password',$request->param('password'));


        $this->redirect('/index/login/index');
    }
}
