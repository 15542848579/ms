var _date;
layui.use(['form', 'laydate'], function () {
    var form = layui.form, laydate = layui.laydate;
    //全选
    form.on('checkbox(allChoose)', function (data) {
        var child = $(data.elem).parents('table').find('tbody input[type="checkbox"]');
        child.each(function (index, item) {
            item.checked = data.elem.checked;
        });
        form.render('checkbox');
    });
    //搜索
    form.on('select(search_select)', function (data) {
        var url = window.location.href;
        goUrl(url, data.elem.name, data.value);
    });
    //执行一个laydate实例
    _date = function (param) {
        laydate.render({
            elem: param['this'] //指定元素
            , show: true //直接显示
            , closeStop: param['this']//这里代表的意思是：点击 test1 所在元素阻止关闭事件冒泡。如果不设定，则无法弹出控件
            , theme: 'molv'
            , calendar: true
            , format: param['format']
            , min: param['min']
            , max: param['max']
            , zIndex: 99999999
            , type: 'datetime'
        });
    }
});

/*日历控件*/
function GetDate(_this) {
    var format = _this.getAttribute('format');
    var min = _this.getAttribute('min');
    var max = _this.getAttribute('max');
    _date({
        'this': _this,
        'format': format ? format : "yyyy-MM-dd HH:mm:ss",
        'min': min ? '' : "1900-1-1 0:00:00",
        'max': max ? '' : "3000-1-1 0:00:00",
    })
}

/*选择*/
function getChecks() {
    var str = "";
    var elm = document.getElementsByName("ids");
    for (var i = 0; i < elm.length; i++) {
        var e = elm[i];
        if (e.name == "ids" && e.checked == true) {
            str = str + e.value + ",";
        }
    }
    if (str != "") {
        str = str.substring(0, str.length - 1);
    }
    return str;
}

/*删除所有*/
function deleteAll(_this) {
    var str = getChecks();
    if (str == "") {
        layer.msg('请选择要删除的项目!');
        return;
    }
    layer.confirm("确定真的要删除吗?", function (index) {
        var data = {"id": str};
        $.ajax({
            type: "DELETE", url: $(_this).attr('url'), data: data, async: true, dataType: "json",
            success: function (data) {
                if (1 == data.code) {
                    layer.msg('已删除!', {icon: 1, time: 1200});
                    window.location.reload();//刷新页面
                } else {
                    layer.msg(data.msg, {icon: 2, time: 1200});
                }
            }, error: function (XMLHttpRequest, textStatus, errorThrown) {
                layer.msg('服务器未正常响应，请稍后重试', {icon: 5, time: 1200});
            }
        })
    })
}

/*用户真删除*/
function del(_this, id, tip) {
    layer.confirm((tip ? tip : '删除不可恢复,确认要删除吗?'), function (index) {
        $.ajax({
            type: "DELETE", url: $(_this).attr('url'), data: {id: id}, async: true, dataType: "json",
            success: function (result) {
                if (1 == result.code) {
                    layer.msg(result.msg, {icon: 1, time: 1500});
                    location.reload();
                } else {
                    layer.msg(result.msg, {icon: 2, time: 1500});
                }
            }, error: function (XMLHttpRequest, textStatus, errorThrown) {
                layer.msg('服务器未正常响应，请稍后重试', {icon: 5, time: 1000});
            }
        });
    });
}

//获取选中的复选框值
function getCheckedId(name) {
    var id = "";
    $("input[name^='" + name + "']").each(function (i, el) {
        if ($("input[name='" + el.name + "']").is(':checked') == true) {
            id += $(this).val() + ","
            //console.log(el.name)
        }
    });
    return id.substring(0, id.length - 1);
}

//获取未选中的复选框值
function getNoCheckedId(name) {
    var id = "";
    $("input[name^='" + name + "']").not("input:checked").each(function (i, el) {
        id += $(this).attr("data") + ","
    });
    return id.substring(0, id.length - 1);
}

/*默认小窗口添加*/
function small_edit(_this, title, w, h) {
    var url = $(_this).attr('url');
    var data = eval($(_this).attr('data-id'));
    if (_this.elem) {
        url = _this.elem.url
        data = _this.value
    }
    if (data) {
        url = url + "?" + data
    }
    layer.open({
        type: 2,
        title: title,
        shadeClose: true,
        shade: 0.8,
        anim: Math.floor(Math.random() * 6 + 0), //0-6的动画形式，-1不开启
        area: [w ? w : '60%', h ? h : '70%'],
        content: url,//iframe的url
        success: function (layero, index) {
            setTimeout(function () {
                layer.tips('点击此处返回列表', '.layui-layer-setwin .layui-layer-close', {
                    tips: 3
                });
            }, 500)
        }
    });
}

/*默认大窗口添加*/
function edit(_this, title) {
    var url = $(_this).attr('url');
    var index = layer.open({
        type: 2,
        title: title,
        content: url,
        area: ['500px', '500px'],
        maxmin: false,
        anim: Math.floor(Math.random() * 6 + 0), //0-6的动画形式，-1不开启
        shade: 0.8, //遮罩透明度
        success: function (layero, index) {
            setTimeout(function () {
                layer.tips('点击此处返回列表', '.layui-layer-setwin .layui-layer-close', {
                    tips: 3
                });
            }, 200)
        }
    });
    layer.full(index);
}

/*修改*/
function _update(_this, refresh) {
    var data = eval($(_this).attr('data'));
    $.ajax({
        type: 'PUT',
        async: true,
        data: data,
        url: $(_this).attr('url'),
        success: function (result) {
            if (1 == result.code) {
                layer.msg(result.msg, {icon: 6, time: 1000});
                if (refresh == undefined || refresh == '') {
                    location.reload();
                }
            } else {
                layer.msg(result.msg, {icon: 5, time: 1000});
            }
        }, error: function (XMLHttpRequest, textStatus, errorThrown) {
            layer.msg('服务器未正常响应，请稍后重试', {icon: 5, time: 1000});
        }
    })
}

function clear_up() {
    layer.confirm('确认要清除缓存吗？', function (index) {
        $.ajax({
            type: 'GET',
            async: true,
            dataType: "json",
            url: _CLEAR_URL,
            success: function (result) {
                if (result.code == 1) {
                    layer.msg(result.msg, {icon: 6, time: 1000});
                } else {
                    layer.msg(result.msg, {icon: 5, time: 1000});
                }
            }, error: function (XMLHttpRequest, textStatus, errorThrown) {
                layer.msg('服务器未正常响应，请稍后重试', {icon: 5, time: 1000});
            }
        })
    })
}

/*关闭*/
function close_this(isLoad) {
    var index = parent.layer.getFrameIndex(window.name);
    parent.layer.close(index);
    if (isLoad == false) {
        parent.location.reload();
    }
}

/*确认*/
function confirm(_this, tip) {
    var data = eval($(_this).attr('data'));
    layer.confirm(tip, function (index) {
        $.ajax({
            type: "POST", url: $(_this).attr('url'), data: data, async: true, dataType: "json",
            success: function (result) {
                if (1 == result.status) {
                    layer.msg(result.msg, {icon: 5, time: 1500});
                } else {
                    layer.msg(result.msg, {icon: 6, time: 1500});
                }
            }, error: function (XMLHttpRequest, textStatus, errorThrown) {
                layer.msg('服务器未正常响应，请稍后重试', {icon: 5, time: 1000});
            }
        });
    });
}

/*跳转多少页码*/
function page_jump(_this) {
    var page = $("input[name='page']").val();
    var url = window.location.href;
    goUrl(url, 'page', page);
}

/*加载多少项*/
function load_item(_this) {
    var item = $(_this).val();
    var url = window.location.href;
    var new_url = url.replace(/(?![?&])(page)=\w+/gi, "page=1");
    goUrl(new_url, 'item', item);
}

/*搜索*/
function search_keyword(_this, name) {
    if (name.indexOf(",") > -1) {
        var name = name.split(',');
        var values = [];
        name.forEach(function (item, index) {
            values[index] = $('input[name="' + item + '"]').val();
        })
        var url = window.location.href;
        var url = url.replace(/(?![?&])(page)=\w+/gi, "page=1");
        goMore(url, name, values)
    } else {
        var search = $('input[name="' + name + '"]').val();
        var url = window.location.href;
        var url = url.replace(/(?![?&])(page)=\w+/gi, "page=1");
        goUrl(url, name, search);
    }
}

/*重置url参数*/
function reset_url() {
    var url = window.location.href;
    var urls = url.split('?');
    window.location.replace(urls[0]);
}

function goMore(url, names, values) {
    var is_param = url.indexOf("?");
    var urls = url;
    var new_url = '';
    if (is_param >= 0) {
        names.forEach(function (item, index) {
            new_url = changPearam(urls, item, values[index])
            urls = new_url;
        })
    } else {
        names.forEach(function (item, index) {
            if (index == 0) {
                urls = urls + "?" + item + "=" + values[index];
            } else {
                urls = urls + '&' + item + "=" + values[index];
            }
        })
    }
    window.location.replace(urls);
}

/*添加参数*/
function goUrl(url, name, value) {
    var is_param = url.indexOf("?");
    if (is_param > 0) {
        var new_url = changPearam(url, name, value)
    } else {
        var new_url = url + "?" + name + "=" + value;
    }
    window.location.replace(new_url);
}

/*修改当前url参数*/
function changPearam(url, name, value) {
    var str = "";
    if (url.indexOf('?') != -1)
        str = url.substr(url.indexOf('?') + 1);
    else
        return url + "?" + name + "=" + value;
    var returnurl = "";
    var setparam = "";
    var arr;
    var modify = "0";
    if (str.indexOf('&') != -1) {
        arr = str.split('&');

        for (i in arr) {
            if (arr[i].split('=')[0] == name) {
                setparam = value;
                modify = "1";
            }
            else {
                setparam = arr[i].split('=')[1];
            }
            returnurl = returnurl + arr[i].split('=')[0] + "=" + setparam + "&";
        }

        returnurl = returnurl.substr(0, returnurl.length - 1);

        if (modify == "0")
            if (returnurl == str)
                returnurl = returnurl + "&" + name + "=" + value;
    }
    else {
        if (str.indexOf('=') != -1) {
            arr = str.split('=');

            if (arr[0] == name) {
                setparam = value;
                modify = "1";
            }
            else {
                setparam = arr[1];
            }
            returnurl = arr[0] + "=" + setparam;
            if (modify == "0")
                if (returnurl == str)
                    returnurl = returnurl + "&" + name + "=" + value;
        }
        else
            returnurl = name + "=" + value;
    }
    return url.substr(0, url.indexOf('?')) + "?" + returnurl;
}

/*从数组中删除指定值*/
function removeByValue(arr, val) {
    for (var i = 0; i < arr.length; i++) {
        if (arr[i] == val) {
            arr.splice(i, 1);
            break;
        }
    }
}

function prompts(_this, name, title, value, formType) {
    layer.prompt({
        formType: (formType == undefined) ? 3 : formType,
        value: (value == undefined) ? '' : value,
        title: (title == undefined) ? '温馨提示' : title
    }, function (val, index) {
        var data = eval($(_this).attr('data-id')) + "&" + name + "=" + val;
        $.ajax({
            type: 'PUT',
            async: true,
            data: data,
            url: $(_this).attr('url'),
            success: function (result) {
                if (1 == result.code) {
                    layer.msg(result.msg, {icon: 6, time: 1000});
                    if (refresh == undefined || refresh == '') {
                        location.reload();
                    }
                } else {
                    layer.msg(result.msg, {icon: 5, time: 1000});
                }
            }, error: function (XMLHttpRequest, textStatus, errorThrown) {
                layer.msg('服务器未正常响应，请稍后重试', {icon: 5, time: 1000});
            }
        })
        layer.close(index);
    });
}

/*刷新*/
function reload() {
    location.reload()
}