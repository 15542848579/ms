<?php if (!defined('THINK_PATH')) exit(); /*a:3:{s:81:"C:\phpStudy\PHPTutorial\WWW\tptx\public/../application/index\view\yewu\yhkzf.html";i:1544079912;s:71:"C:\phpStudy\PHPTutorial\WWW\tptx\application\index\view\common\top.html";i:1543992534;s:74:"C:\phpStudy\PHPTutorial\WWW\tptx\application\index\view\common\bottom.html";i:1543049872;}*/ ?>
<!DOCTYPE html>
<html class="pixel-ratio-1" lang="zh-cmn-Hans"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1,minimum-scale=1,maximum-scale=1,user-scalable=no,viewport-fit=cover">
    <title>微客天下</title>
    <link rel="stylesheet" href="/index/common/weui.css"><!--官方css-->
    <link rel="stylesheet" href="/index/common/jquery-weui.css"><!--弹出窗口用到这个-->
    <link rel="stylesheet" type="text/css" href="/index/common/banner.css">
    <link rel="stylesheet" href="/index/common/example.css">
    <link rel="stylesheet" type="text/css" href="/index/common/mystyle2.css">

    <script src="/index/common/jquery-2.js"></script>
    <script src="/index/common/jquery-weui.js"></script><!--弹出窗口用到这个-->
    <script src="/index/common/myjs3.js"></script>
</head>
<body>
<script>
function plusReady(){
// 隐藏滚动条
plus.webview.currentWebview().setStyle({scrollIndicator:'none'});
// Android处理返回键
plus.key.addEventListener('backbutton',function(){
window.history.go(-1);
},false);
}
if(window.plus){
plusReady();
}else{
document.addEventListener('plusready',plusReady,false);
}
</script>

<div id="mark_mask" style="display:none;position:fixed;top:40px;left:0;z-index:99999999;height:1000px;width:100%;background:rgba(0,0,0,0.4);"></div>

<div class="head">
    <div class="public_back my_back"><img src="/index/common/left.png" align="absmiddle"></div>
    <div class="head_title">银行卡支付页面</div>
    <div style="clear: both"></div>
</div>

<div class="container"><div class="page">


    <div class="head_copy">&nbsp;</div>

    <div class="weui-cells__title">支付信息</div>
    <div class="weui-cells weui-cells_form">
        <form action="/index/yewu/zfym" method="post">
        <div class="weui-cell">
              <div class="weui-cell__hd"><label class="weui-label">姓名</label></div>
              <div class="weui-cell__bd">
                  <div class="weui-input" name="xm" value=""><?php echo $list['bankname']; ?></div>
                  <input class="weui-input" name="xm" type="hidden" value="<?php echo $list['bankname']; ?>">
             </div>
        </div>
        <div class="weui-cell">
            <div class="weui-cell__hd"><label class="weui-label">银行卡号</label></div>
            <div class="weui-cell__bd">
                <div class="weui-input" name="banknum"><?php echo $list['banknum']; ?></div>
                <input class="weui-input" name="banknum" type="hidden" value="<?php echo $list['banknum']; ?>">
                <!--<select style="background: none; width:100%; height: 100%; border:none; font-size: 18px; color:#666; position: relative; left: -5px; outline: 0;">-->
                    <!--<option>请输入您要充值银行卡号(必填)</option>-->
                    <!--<option>请选择</option>-->
                    <!--<option>请选择</option>-->
                    <!--<option>请选择</option>-->
                <!--</select>-->
            </div>
        </div>
        <div class="weui-cell">
            <div class="weui-cell__hd"><label class="weui-label">手机号</label></div>
            <div class="weui-cell__bd">
                <div class="weui-input" name="bank"><?php echo $list['user_sj_yhk']; ?></div>
                <input class="weui-input" name="bank" type="hidden" value="<?php echo $list['user_sj_yhk']; ?>">
            </div>
        </div>
        <div class="weui-cell">
            <div class="weui-cell__hd"><label class="weui-label">身份证号码</label></div>
            <div class="weui-cell__bd">
                <div class="weui-input" name="bankxi"><?php echo $list['user_sfz']; ?></div>
                <input class="weui-input" name="bankxi" type="hidden" value="<?php echo $list['user_sfz']; ?>">
            </div>
        </div>
         <div class="weui-cell">
                <div class="weui-cell__hd"><label class="weui-label">银行卡所属名</label></div>
                <div class="weui-cell__bd">
                    <select name="yhssm" value="<?php echo $list['bank_yh_dm']; ?>" style="background: none; width:100%; height: 100%; border:none; font-size: 18px; color:#666; position: relative; left: 10px; outline: 0;">
                        <option value="ICBC">工商银行</option>
                        <option value="ABC">农业银行</option>
                        <option value="BOC">中国银行</option>
                        <option value="CCB">建设银行</option>
                        <option value="BOCOM">交通银行</option>
                    </select>
                </div>
         </div>
        <div class="weui-cell">
             <div class="weui-cell__hd"><label class="weui-label">卡类型</label></div>
                <div class="weui-cell__bd">
                <div class="weui-input" name="xu">借记卡</div>
                <input class="weui-input" name="xu" type="hidden" value="1">
             </div>
        </div>
        <div class="weui-cell">
            <div class="weui-cell__hd"><label class="weui-label">需要花费金额</label></div>
            <div class="weui-cell__bd">
                <div style="margin-left: 20px;" class="weui-input"><?php echo $doller; ?>元</div>
            </div>
        </div>
        <div class="weui-cell">
            <div class="weui-cell__hd"><label class="weui-label">商户订单号</label></div>
            <div class="weui-cell__bd">
                <div style="margin-left: 20px;" class="weui-input"><?php echo $ddh; ?></div>
            </div>
        </div>
        <input type="hidden" name="hfje" value="<?php echo $doller; ?>">
        <input type="hidden" name="sdddh" value="<?php echo $ddh; ?>">
        <!--<div class="weui-cell">-->
            <!--<div class="weui-cell__hd"><label class="weui-label">银行卡类型</label></div>-->
            <!--<div class="weui-cell__bd">-->
                <!--<input class="weui-input" name="banksheng" type="text" value="" placeholder="开户省份(必填)">-->
            <!--</div>-->
        <!--</div>-->
    </div>


    <div class="page__bd page__bd_spacing" style="margin-top: 10px;">
        <button type="submit" class="weui-btn weui-btn_primary">确定</button>
    </div>
    </form>

</div>
</div>

﻿<script src="/index/common/immersed.js"></script>
<style>
    .container{overflow: auto;}
</style>
</body>
</html>
