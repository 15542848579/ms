<?php if (!defined('THINK_PATH')) exit(); /*a:3:{s:77:"/www/wwwroot/7.ccooffee/tptx/public/../application/index/view/yewu/renwu.html";i:1544088082;s:67:"/www/wwwroot/7.ccooffee/tptx/application/index/view/common/top.html";i:1543992534;s:70:"/www/wwwroot/7.ccooffee/tptx/application/index/view/common/bottom.html";i:1543049872;}*/ ?>
<!DOCTYPE html>
<html class="pixel-ratio-1" lang="zh-cmn-Hans"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1,minimum-scale=1,maximum-scale=1,user-scalable=no,viewport-fit=cover">
    <title>微客天下</title>
    <link rel="stylesheet" href="/index/common/weui.css"><!--官方css-->
    <link rel="stylesheet" href="/index/common/jquery-weui.css"><!--弹出窗口用到这个-->
    <link rel="stylesheet" type="text/css" href="/index/common/banner.css">
    <link rel="stylesheet" href="/index/common/example.css">
    <link rel="stylesheet" type="text/css" href="/index/common/mystyle2.css">

    <script src="/index/common/jquery-2.js"></script>
    <script src="/index/common/jquery-weui.js"></script><!--弹出窗口用到这个-->
    <script src="/index/common/myjs3.js"></script>
</head>
<body>
<script>
function plusReady(){
// 隐藏滚动条
plus.webview.currentWebview().setStyle({scrollIndicator:'none'});
// Android处理返回键
plus.key.addEventListener('backbutton',function(){
window.history.go(-1);
},false);
}
if(window.plus){
plusReady();
}else{
document.addEventListener('plusready',plusReady,false);
}
</script>

<div id="mark_mask" style="display:none;position:fixed;top:40px;left:0;z-index:99999999;height:1000px;width:100%;background:rgba(0,0,0,0.4);"></div>
﻿<div class="head">
    <div class="public_back my_back"><img src="/index/common/left.png" align="absmiddle"></div>
    <div class="head_title">微客天下</div>
    <div style="clear: both"></div>
</div>
<div class="container"><div class="page">

    <div class="head_copy">&nbsp;</div>
    <form action="/index/yewu/dorenwu" method="post" enctype="multipart/form-data">

        <div class="weui-cell">
            <div class="weui-cell__hd"><label class="weui-label">标题</label></div>
            <div class="weui-cell__bd">
                <input class="weui-input" type="type" placeholder="请输入广告标题(最多12字符)" name="title">
            </div>
        </div>

        <div class="borderxian">
            <div class="weui-cell">
                <div class="weui-cell__bd">
                    <textarea class="weui-textarea" placeholder="请输入广告内容(最多150个字符)" rows="3" name="content"></textarea>

                </div>
            </div>
            <div class="weui_uploader_input_wrp">
            <input type="file" name="img" id="xdaTanFileImg" onchange="xmTanUploadImg(this)" class="weui-btn weui-btn_mini weui-btn_primary" style="width:100% !important; height:40px !important; background: none !important;">

            <input type="file" name="img2" id="xdaTanFileImg2" onchange="xmTanUploadImg2(this)" class="weui-btn weui-btn_mini weui-btn_primary" style="width:100% !important; height:40px !important; background: none !important;">
            </div>
            <div class="weui-textarea-counter">*温馨提示:图片比例最好为4:3,5:3,16:9</div>
        </div>
            <img id="xmTanImg"/ height="200px" width="160px">
            <img id="xmTanImg2"/ height="200px" width="160px">
        <div class="weui-cells weui-cells_form">
            <div class="weui-cell">
                <div class="weui-cell__hd"><label class="weui-label">单笔广告费</label></div>
                <div class="weui-cell__bd">
                    <input class="weui-input" type="text" value="4" name="danjia" id="task_danjia" onkeydown="" disabled="">
                </div>
            </div>
            <div class="weui-cell">
                <div class="weui-cell__hd"><label class="weui-label">发布数量</label></div>
                <div class="weui-cell__bd">
                    <input class="weui-input" type="text" placeholder="最低发布数量为100条" name="num" id="task_num" value="100" min="100" step="20">
                </div>
            </div>
            <div class="weui-cell">
                <div class="weui-cell__hd"><label class="weui-label">广告总价</label></div>
                <div class="weui-cell__bd">
                    <input class="weui-input" type="text" placeholder="0" name="sum" value="400" id="task_sum" readonly="readonly">
                </div>
            </div>

        </div>

    <div class="page__bd page__bd_spacing" style="margin-top: 10px;">
    	<input type="submit" value="确定" class="weui-btn weui-btn_primary">
    </div>
    </form>


</div></div>

<div id="upload_div" style="display:none"></div>

<style type="text/css">
    .container{background: #ffffff;}
    .borderxian{ border:1px solid gray;margin: 5px;}
    .weui-textarea-counter{text-align: left;}
    .upimgproduct{width: 60px;height:60px;border:1px dotted gray;margin-left: 10px;}

</style>
<script type="text/javascript">            
            //判断浏览器是否支持FileReader接口
            if (typeof FileReader == 'undefined') {
                
                document.getElementById("xdaTanFileImg").setAttribute("disabled", "disabled");
            }

            //选择图片，马上预览
            function xmTanUploadImg(obj) {
                var file = obj.files[0];
                
                console.log(obj);console.log(file);
                console.log("file.size = " + file.size);  //file.size 单位为byte

                var reader = new FileReader();

                //读取文件过程方法
                reader.onloadstart = function (e) {
                    console.log("开始读取....");
                }
                reader.onprogress = function (e) {
                    console.log("正在读取中....");
                }
                reader.onabort = function (e) {
                    console.log("中断读取....");
                }
                reader.onerror = function (e) {
                    console.log("读取异常....");
                }
                reader.onload = function (e) {
                    console.log("成功读取....");

                    var img = document.getElementById("xmTanImg");
                    img.src = e.target.result;
                    //或者 img.src = this.result;  //e.target == this
                }

                reader.readAsDataURL(file)
            }
        </script> 
        <script type="text/javascript">            
            function xmTanUploadImg2(obj) {
                var file = obj.files[0];
                
                console.log(obj);console.log(file);
                console.log("file.size = " + file.size);  //file.size 单位为byte

                var reader = new FileReader();

                //读取文件过程方法
                reader.onloadstart = function (e) {
                    console.log("开始读取....");
                }
                reader.onprogress = function (e) {
                    console.log("正在读取中....");
                }
                reader.onabort = function (e) {
                    console.log("中断读取....");
                }
                reader.onerror = function (e) {
                    console.log("读取异常....");
                }
                reader.onload = function (e) {
                    console.log("成功读取....");

                    var img = document.getElementById("xmTanImg2");
                    img.src = e.target.result;
                    //或者 img.src = this.result;  //e.target == this
                }

                reader.readAsDataURL(file)
            }
        </script>
﻿<script src="/index/common/immersed.js"></script>
<style>
    .container{overflow: auto;}
</style>
</body>
</html>