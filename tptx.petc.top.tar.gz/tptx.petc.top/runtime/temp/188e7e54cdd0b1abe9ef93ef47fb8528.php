<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:80:"D:\phpStudy\PHPTutorial\WWW\gg\public/../application/index\view\login\index.html";i:1543212088;s:69:"D:\phpStudy\PHPTutorial\WWW\gg\application\index\view\common\top.html";i:1543079499;}*/ ?>
<!DOCTYPE html>
<html class="pixel-ratio-1" lang="zh-cmn-Hans"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1,minimum-scale=1,maximum-scale=1,user-scalable=no,viewport-fit=cover">
    <title>微广告</title>
    <link rel="stylesheet" href="/index/common/weui.css"><!--官方css-->
    <link rel="stylesheet" href="/index/common/jquery-weui.css"><!--弹出窗口用到这个-->
    <link rel="stylesheet" type="text/css" href="/index/common/banner.css">
    <link rel="stylesheet" href="/index/common/example.css">
    <link rel="stylesheet" type="text/css" href="/index/common/mystyle2.css">

    <script src="/index/common/jquery-2.js"></script>
    <script src="/index/common/jquery-weui.js"></script><!--弹出窗口用到这个-->
    <script src="/index/common/myjs3.js"></script>
</head>
<body>
<script>
function plusReady(){
// 隐藏滚动条
plus.webview.currentWebview().setStyle({scrollIndicator:'none'});
// Android处理返回键
plus.key.addEventListener('backbutton',function(){
window.history.go(-1);
},false);
}
if(window.plus){
plusReady();
}else{
document.addEventListener('plusready',plusReady,false);
}
</script>

﻿<div class="container">
    <article class="weui-article">
        <div class="logodiv"><img src="/index/common/logo.png"></div>

    </article>


    <form method="post" action="/index/login/regist">

            <div class="weui-cell">
                <input type="text" class="weui-input" name="username" placeholder="请输入用户名">
            </div>
            <div class="weui-cell">

                <input type="password" class="weui-input" name="password" placeholder="请输入密码"></div>


            <div class="weui-cell">

                <div class="weui-cell__bd">
                    <input type="text" class="weui-input" name="yzm" placeholder="验证码">
                </div>
                <div>
                 <img src="<?php echo captcha_src(); ?>" onclick="this.src=this.src+'?'" style="margin-top: 0px;">

                </div>
            </div>
        <div style="clear: both;height:10px;"></div>
        <div class="page__bd page__bd_spacing">
          <input type="submit" value="登 录" class="weui-btn weui-btn_primary">
        </div>
        <div style="clear: both;height:10px;"></div>
        <p class="weui-footer">
            </p>
            <div style="text-align: center;"><a href="/index/login/wangji">找回密码</a></div>
            <div style="text-align: center;" id="redata" class="redata">&nbsp;</div>
        <p></p>



    </form>

 </div>

<style>
.logodiv{text-align: center;}
    .logodiv img{width: 100px;margin-top: 20px;}
    h1{text-align: center;color: gray;}
</style>

﻿<script src="/index/common/immersed.js"></script>

</body></html>