<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:63:"D:\tptx\tptx\public/../application/admin\view\index\notice.html";i:1543176816;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <title>Data-Table 表格</title>
    <link rel="stylesheet" href="../frame/layui/css/layui.css">
    <!--<link rel="stylesheet" href="http://cdn.datatables.net/1.10.13/css/jquery.dataTables.min.css">-->
    <link rel="stylesheet" href="../frame/static/css/style.css">
    <link rel="icon" href="../frame/static/image/code.png">
</head>
<body>

<div class="admin-main">
    <blockquote class="layui-elem-quote quoteBox">
        <form class="layui-form" action="/admin/index/notice" method="post">
            <div class="layui-inline">
                <div class="layui-input-inline">
                    <input name="keyword" value="" placeholder="请输入搜索关键词"
                           class="layui-input searchVal" type="text">
                </div>
            </div>
            <div class="layui-inline">
                <button class="layui-btn layui-btn-sm">
                    <i class="layui-icon">&#xe615;</i> 搜索
                </button>
            </div>
            <div class="layui-inline">
                <a href="javascript:location.reload();" class="layui-btn layui-btn-normal layui-btn-sm">
                    <i class="layui-icon">&#x1002;</i> 刷新
                </a>
            </div>
        </form>
    </blockquote>
    <fieldset class="layui-elem-field">
        <legend>用户查询</legend>
        <div class="layui-field-box layui-form">
            <table class="layui-table admin-table" lay-even lay-skin="row">
                <thead>
                <?php if(!(empty($list) || (($list instanceof \think\Collection || $list instanceof \think\Paginator ) && $list->isEmpty()))): ?>
                <tr>
                    <th>公告ID</th>
                    <th>公告标题</th>
                    <th>发表时间</th>
                    <th>文字内容</th>
                    <th>是否显示</th>
                    <th>删除</th>
                </tr>
                <?php endif; ?>
                </thead>
                <tbody>
                <?php if(is_array($list) || $list instanceof \think\Collection || $list instanceof \think\Paginator): $i = 0; $__LIST__ = $list;if( count($__LIST__)==0 ) : echo "没有值" ;else: foreach($__LIST__ as $key=>$row): $mod = ($i % 2 );++$i;?>
                <tr class="checkbox">
                    <td>
                        <?php echo $row['id']; ?>
                    </td>
                    <td>
                        <?php echo $row['title']; ?>
                    </td>
                    <td>
                        <?php echo $row['time']; ?>
                    </td>
                    <td>
                        <?php echo $row['article']; ?>
                    </td> 
                     <td>
                        <div class="layui-table-cell laytable-cell-1-7">
                            <?php switch($row['status']): case "0": ?>
                            <a class="layui-btn layui-btn-xs layui-btn-warm"
                               data="'id=<?php echo $row['id']; ?>&status=1'" onclick="_update(this)"
                               url="<?php echo url('admin/index/notice1'); ?>">已显示</a>
                            <?php break; case "1": ?>
                            <a class="layui-btn layui-btn-xs layui-btn-danger"
                               data="'id=<?php echo $row['id']; ?>&status=0'" onclick="_update(this)"
                               url="<?php echo url('admin/index/notice1'); ?>">已隐藏</a>
                            <?php break; endswitch; ?>
                        </div>

                    </td>
                    <td>
                        <div class="layui-table-cell laytable-cell-1-7">
                            <a class="layui-btn layui-btn-xs layui-btn-danger" onclick="{if(confirm('确定要删除吗?')){return true;}return false;}" href="/admin/index/delete1?id=<?php echo $row['id']; ?>">删除</a>
                        </div>
                    </td>
                </tr>
                <?php endforeach; endif; else: echo "没有值" ;endif; ?>
                </tbody>
            </table>
        </div>


    </fieldset>

</div>
<div class="admin-table-page" style="text-align: center;">
    <div class="layui-box layui-laypage layui-row">
        <div class="layui-col-xs12 layui-col-sm7 layui-col-md6">
            {<?php echo trim($list->render()); ?>}
        </div>
    </div>
</div>
<script type="text/javascript" src="../js/jquery.js"></script>
<script type="text/javascript" src="../frame/layui/layui.js"></script>
<script type="text/javascript" src="../js/admin.js"></script>
<script type="text/javascript" src="../js/index.js"></script>
</body>
</html>