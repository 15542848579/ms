<?php if (!defined('THINK_PATH')) exit(); /*a:3:{s:80:"D:\phpStudy\PHPTutorial\WWW\tptx\public/../application/index\view\renwu\qtj.html";i:1543735216;s:71:"D:\phpStudy\PHPTutorial\WWW\tptx\application\index\view\common\top.html";i:1543644626;s:74:"D:\phpStudy\PHPTutorial\WWW\tptx\application\index\view\common\bottom.html";i:1543049873;}*/ ?>
<!DOCTYPE html>
<html class="pixel-ratio-1" lang="zh-cmn-Hans"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1,minimum-scale=1,maximum-scale=1,user-scalable=no,viewport-fit=cover">
    <title>同屏时代</title>
    <link rel="stylesheet" href="/index/common/weui.css"><!--官方css-->
    <link rel="stylesheet" href="/index/common/jquery-weui.css"><!--弹出窗口用到这个-->
    <link rel="stylesheet" type="text/css" href="/index/common/banner.css">
    <link rel="stylesheet" href="/index/common/example.css">
    <link rel="stylesheet" type="text/css" href="/index/common/mystyle2.css">

    <script src="/index/common/jquery-2.js"></script>
    <script src="/index/common/jquery-weui.js"></script><!--弹出窗口用到这个-->
    <script src="/index/common/myjs3.js"></script>
</head>
<body>
<script>
function plusReady(){
// 隐藏滚动条
plus.webview.currentWebview().setStyle({scrollIndicator:'none'});
// Android处理返回键
plus.key.addEventListener('backbutton',function(){
window.history.go(-1);
},false);
}
if(window.plus){
plusReady();
}else{
document.addEventListener('plusready',plusReady,false);
}
</script>

<div id="mark_mask" style="display:none;position:fixed;top:40px;left:0;z-index:99999999;height:1000px;width:100%;background:rgba(0,0,0,0.4);"></div>
﻿<div class="head">
    <div class="public_back my_back"><img src="/index/common/left.png" align="absmiddle"></div>
    <div class="head_title">任务详情</div>
    <div style="clear: both"></div>
</div>

<div class="container"><div class="page">

    <div class="head_copy">&nbsp;</div>

    <div class="weui-panel weui-panel_access">
        <div class="weui-panel__hd"><h4 class="weui-media-box__title">【<?php switch($list['level']): case "0": ?>游客	<?php break; case "1": ?>会员<?php break; endswitch; ?>】【<?php echo $list['title']; ?>】</h4></div>
        <div class="weui-panel__bd">
            <div class="weui-media-box weui-media-box_text">

                <p class="weui-media-box__desc">
                    <textarea style=" outline:none;  border:none;width: 100%;height: 70px;" id="bar" autocomplete="off" autocorrect="off" autocapitalize="off" spellcheck="false">【<?php echo $list['title']; ?>】<?php echo $list['ad']; ?></textarea>

                </p>
            </div>
        </div>
        <form action="/index/renwu/dotj" method="post" enctype="multipart/form-data">
        <div class="weui-panel__ft btn">
            <a href="javascript:void(0);" class="weui-cell weui-cell_access weui-cell_link">
                <input class="upimgproduct"  name="img" type="file" id="xdaTanFileImg" onchange="xmTanUploadImg(this)" accept="image"/>

                <input type="button" value="隐藏图片" onclick="document.getElementById('xmTanImg').style.display = 'none';"/>
                <input type="button" value="显示图片" onclick="document.getElementById('xmTanImg').style.display = 'block';"/>
                <div id="xmTanDiv"></div>
                <img id="xmTanImg"/ height="200px">

            </a>
        </div>
    </div>
    <input type="hidden" name="id" value="<?php echo $list['id']; ?>">



    <div class="page__bd page__bd_spacing" style="margin-top: 10px;margin-bottom: 20px;">
        <input type="submit" value="提交任务" class="weui-btn weui-btn_primary">
    </div>
	</form>

    <div style="text-align: center;" id="tupiantip"></div>
</div></div>
<script type="text/javascript">            
            //判断浏览器是否支持FileReader接口
            if (typeof FileReader == 'undefined') {
                document.getElementById("xmTanDiv").InnerHTML = "<h1>当前浏览器不支持FileReader接口</h1>";
                //使选择控件不可操作
                document.getElementById("xdaTanFileImg").setAttribute("disabled", "disabled");
            }

            //选择图片，马上预览
            function xmTanUploadImg(obj) {
                var file = obj.files[0];
                
                console.log(obj);console.log(file);
                console.log("file.size = " + file.size);  //file.size 单位为byte

                var reader = new FileReader();

                //读取文件过程方法
                reader.onloadstart = function (e) {
                    console.log("开始读取....");
                }
                reader.onprogress = function (e) {
                    console.log("正在读取中....");
                }
                reader.onabort = function (e) {
                    console.log("中断读取....");
                }
                reader.onerror = function (e) {
                    console.log("读取异常....");
                }
                reader.onload = function (e) {
                    console.log("成功读取....");

                    var img = document.getElementById("xmTanImg");
                    img.src = e.target.result;
                    //或者 img.src = this.result;  //e.target == this
                }

                reader.readAsDataURL(file)
            }
        </script> 
﻿<script src="/index/common/immersed.js"></script>
<style>
    .container{overflow: auto;}
</style>
</body>
</html>