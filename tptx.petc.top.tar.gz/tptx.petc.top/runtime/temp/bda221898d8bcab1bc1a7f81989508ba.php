<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:80:"D:\phpStudy\PHPTutorial\WWW\gg\public/../application/index\view\index\index.html";i:1543215756;s:71:"D:\phpStudy\PHPTutorial\WWW\gg\application\index\view\common\index.html";i:1543225662;}*/ ?>
<!DOCTYPE html>
<html class="pixel-ratio-1" lang="zh-cmn-Hans"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1,minimum-scale=1,maximum-scale=1,user-scalable=no,viewport-fit=cover">
    <title>微广告</title>
    <link rel="stylesheet" href="/index/common/weui.css"><!--官方css-->
    <link rel="stylesheet" href="/index/common/jquery-weui.css"><!--弹出窗口用到这个-->
    <link rel="stylesheet" type="text/css" href="/index/common/banner.css">
    <link rel="stylesheet" href="/index/common/example.css">
    <link rel="stylesheet" type="text/css" href="/index/common/mystyle2.css">
    <script src="/index/common/jquery-2.js"></script>
    <script src="/index/common/jquery-weui.js"></script><!--弹出窗口用到这个-->
    <script src="/index/common/myjs3.js"></script>
</head>
<body>
<script>
function plusReady(){
// 隐藏滚动条
plus.webview.currentWebview().setStyle({scrollIndicator:'none'});
// Android处理返回键
plus.key.addEventListener('backbutton',function(){
window.history.go(-1);
},false);
}
if(window.plus){
plusReady();
}else{
document.addEventListener('plusready',plusReady,false);
}


</script><div id="mark_mask" style="display:none;position:fixed;top:40px;left:0;z-index:99999999;height:1000px;width:100%;background:rgba(0,0,0,0.4);"></div>
﻿﻿<div class="container" id="container"><div class="page one js_show">

        <div class="swiper-container swiper-container-horizontal" style="height: 200px;">
            <div class="swiper-wrapper" style="transition-duration: 0ms;">
                <div class="swiper-slide swiper-slide-active">
                    <img src="/index/common/banner1.jpg" class=""><div class=" "></div>
                </div>
                <div class="swiper-slide swiper-slide-next">
                    <img src="/index/common/banner2.jpg" class=""><div class=" "></div>
                </div>
                <div class="swiper-slide">
                    <img src="/index/common/banner3.jpg" class=""><div class=""></div>
                </div>
            </div><div class="swiper-pagination swiper-pagination-white swiper-pagination-clickable swiper-pagination-bullets"></div>
        </div>



        <div class="notice" style="overflow:hidden;line-height: 35px;color:gray;height:35px;">
            <div style="position: absolute;padding:5px;z-index: 2;background: #fff">
                <img src="/index/common/notice.png" style="width:20px;height:20px;">
            </div>
            <marquee style="z-index: -1;" scrollamount="3" loop="infinite">任务满两个小时后提交，提前提交不予通过！每天只有两次任务机会，如果上传图片没到两个小时，传错图片，系统都驳回，也就少了一次任务机会！切记！</marquee>
        </div>



                <div class="weui-grids" style="z-index: 10;">
            <a href="/index/yewu/index" class="weui-grid js_grid">
                <div class="weui-grid__icon">
                    <img src="/index/common/grid1.png" alt="">
                </div>
                <p class="weui-grid__label">
                    如何赚佣
                </p>
            </a>
            <a href="/index/yewu/erweima" class="weui-grid js_grid">
                <div class="weui-grid__icon">
                    <img src="/index/common/grid2.png" alt="">
                </div>
                <p class="weui-grid__label">
                    推广二维码
                </p>
            </a>
            <a href="/index/yewu/guanggao" class="weui-grid js_grid">
                <div class="weui-grid__icon">
                    <img src="/index/common/grid3.png" alt="">
                </div>
                <p class="weui-grid__label">
                    广告投放
                </p>
            </a>
            <a href="/index/yewu/huiyuan" class="weui-grid js_grid">
                <div class="weui-grid__icon">
                    <img src="/index/common/grid4.png" alt="">
                </div>
                <p class="weui-grid__label">
                    微广告会员
                </p>
            </a>
            <a href="/index/yewu/renwu" class="weui-grid js_grid">
                <div class="weui-grid__icon">
                    <img src="/index/common/grid5.png" alt="">
                </div>
                <p class="weui-grid__label">
                    发布任务
                </p>
            </a>
            <a href="/index/yewu/mianfei" class="weui-grid js_grid">
                <div class="weui-grid__icon">
                    <img src="/index/common/grid6.png" alt="">
                </div>
                <p class="weui-grid__label">
                    免费领用
                </p>
            </a>
            <a href="/index/yewu/licai" class="weui-grid js_grid">
                <div class="weui-grid__icon">
                    <img src="/index/common/grid7.png" alt="">
                </div>
                <p class="weui-grid__label">
                    广告小费
                </p>
            </a>
            <a href="/index/yewu/qianbao" class="weui-grid js_grid">
                <div class="weui-grid__icon">
                    <img src="/index/common/grid8.png" alt="">
                </div>
                <p class="weui-grid__label">
                    微广告钱包
                </p>
            </a>

            <a href="/index/yewu/chengzhu" class="weui-grid js_grid">
                <div class="weui-grid__icon">
                    <img src="/index/common/grid9.png" alt="">
                </div>
                <p class="weui-grid__label">
                    微广告城主
                </p>
            </a>
            <a href="/index/shop/index" class="weui-grid js_grid">
                <div class="weui-grid__icon">
                    <img src="/index/common/grid10.png" alt="">
                </div>
                <p class="weui-grid__label">
                   物联商城
                </p>
            </a>
            <a href="/index/hongbao/index" class="weui-grid js_grid">
                <div class="weui-grid__icon">
                    <img src="/index/common/grid11.png" alt="">
                </div>
                <p class="weui-grid__label">
                   红包多多
                </p>
            </a>
            <a href="/index/notice/index" class="weui-grid js_grid">
                <div class="weui-grid__icon">
                    <img src="/index/common/grid12.png" alt="">
                </div>
                <p class="weui-grid__label">
                    客服中心
                </p>
            </a>

            <div class="weui-tabbar-tian" style="height: 70px;clear: both;background-color: #f8f8f8;"></div>

        </div>


    </div></div>

<div type="text/html" id="tpl_one" class="onePage">
    <div class="page">

        <div class="swiper-container swiper-container-horizontal" style="height: 747px;">
            <div class="swiper-wrapper" style="transition-duration: 300ms;">
                <div class="swiper-slide swiper-slide-prev">
                    <img src="/index/common/banner1.jpg" class=""><div class=" "></div>
                </div>
                <div class="swiper-slide swiper-slide-active">
                    <img src="/index/common/banner2.jpg" class=""><div class=" "></div>
                </div>
                <div class="swiper-slide swiper-slide-next">
                    <img src="/index/common/banner3.jpg" class=""><div class=""></div>
                </div>
            </div><div class="swiper-pagination swiper-pagination-white swiper-pagination-clickable swiper-pagination-bullets"></div>
        </div>
        <div class="notice" style="overflow:hidden;line-height: 35px;color:gray;height:35px;">
            <div style="position: absolute;padding:5px;z-index: 2;background: #fff">
                <img src="/index/common/notice.png" style="width:20px;height:20px;">
            </div>
            <marquee style="z-index: -1;" scrollamount="3" loop="infinite">任务满两个小时后提交，提前提交不予通过！每天只有两次任务机会，如果上传图片没到两个小时，传错图片，系统都驳回，也就少了一次任务机会！切记！</marquee>
        </div>

                <div class="weui-grids" style="z-index: 10;">
            <a href="/index/yewu/index" class="weui-grid js_grid">
                <div class="weui-grid__icon">
                    <img src="/index/common/grid1.png" alt="">
                </div>
                <p class="weui-grid__label">
                    如何赚佣
                </p>
            </a>
            <a href="/index/yewu/erweima" class="weui-grid js_grid">
                <div class="weui-grid__icon">
                    <img src="/index/common/grid2.png" alt="">
                </div>
                <p class="weui-grid__label">
                    推广二维码
                </p>
            </a>
            <a href="/index/yewu/guanggao" class="weui-grid js_grid">
                <div class="weui-grid__icon">
                    <img src="/index/common/grid3.png" alt="">
                </div>
                <p class="weui-grid__label">
                    广告投放
                </p>
            </a>
            <a href="/index/yewu/huiyuan" class="weui-grid js_grid">
                <div class="weui-grid__icon">
                    <img src="/index/common/grid4.png" alt="">
                </div>
                <p class="weui-grid__label">
                    微广告会员
                </p>
            </a>
            <a href="/index/yewu/renwu" class="weui-grid js_grid">
                <div class="weui-grid__icon">
                    <img src="/index/common/grid5.png" alt="">
                </div>
                <p class="weui-grid__label">
                    发布任务
                </p>
            </a>
            <a href="/index/yewu/mianfei" class="weui-grid js_grid">
                <div class="weui-grid__icon">
                    <img src="/index/common/grid6.png" alt="">
                </div>
                <p class="weui-grid__label">
                    免费领用
                </p>
            </a>
            <a href="/index/yewu/licai" class="weui-grid js_grid">
                <div class="weui-grid__icon">
                    <img src="/index/common/grid7.png" alt="">
                </div>
                <p class="weui-grid__label">
                    广告小费
                </p>
            </a>
            <a href="/index/yewu/qianbao" class="weui-grid js_grid">
                <div class="weui-grid__icon">
                    <img src="/index/common/grid8.png" alt="">
                </div>
                <p class="weui-grid__label">
                    微广告钱包
                </p>
            </a>

            <a href="/index/yewu/chengzhu" class="weui-grid js_grid">
                <div class="weui-grid__icon">
                    <img src="/index/common/grid9.png" alt="">
                </div>
                <p class="weui-grid__label">
                    微广告城主
                </p>
            </a>
            <a href="/index/shop/index" class="weui-grid js_grid">
                <div class="weui-grid__icon">
                    <img src="/index/common/grid10.png" alt="">
                </div>
                <p class="weui-grid__label">
                   物联商城
                </p>
            </a>
            <a href="/index/hongbao/index" class="weui-grid js_grid">
                <div class="weui-grid__icon">
                    <img src="/index/common/grid11.png" alt="">
                </div>
                <p class="weui-grid__label">
                   红包多多
                </p>
            </a>
            <a href="/index/notice/index" class="weui-grid js_grid">
                <div class="weui-grid__icon">
                    <img src="/index/common/grid12.png" alt="">
                </div>
                <p class="weui-grid__label">
                    客服中心
                </p>
            </a>

            <div class="weui-tabbar-tian" style="height: 70px;clear: both;background-color: #f8f8f8;"></div>

        </div>



    </div>


</div>

<div type="text/html" id="tpl_two" class="onePage">

    <div class="page">
        <div class="twopagetop"><img src="/index/common/banner3.jpg" class=""></div>
        <style>
            .twopagetop{width: 100%;}
            .twopagetop img{width: 100%;}
        </style>

        <div class="weui-grids">
            <a href="/index/renwu/index" class="weui-grid js_grid">
                <div class="weui-grid__icon">
                    <img src="/index/common/grid1.png" alt="">
                </div>
                <p class="weui-grid__label">
                    任务大厅
                </p>
            </a>
            <a href="/index/renwu/tijiao" class="weui-grid js_grid">
                <div class="weui-grid__icon">
                    <img src="/index/common/grid2.png" alt="">
                </div>
                <p class="weui-grid__label">
                    提交任务
                </p>
            </a>
            <a href="/index/renwu/log" class="weui-grid js_grid">
                <div class="weui-grid__icon">
                    <img src="/index/common/grid3.png" alt="">
                </div>
                <p class="weui-grid__label">
                    任务记录
                </p>
            </a>
            <div class="weui-tabbar-tian" style="height: 70px;clear: both;background-color: #f8f8f8;"></div>
        </div>
    </div>
</div>

<div type="text/html" id="tpl_three" class="onePage">

    <div class="page">
        <div class="myheader">
            <div class="myhead_data"><img src="/index/common/header.png"></div>
            <div class="myhead_data" style="color:black">
                <div class="myhead_data_text1"><?php echo $list['username']; ?></div>
                <div class="myhead_data_text2"><span>
                    <?php switch($list['level']): case "0": ?>游客<?php break; case "1": ?>普通会员<?php break; case "2": ?>超级会员<?php break; endswitch; ?>
                </span></div>
            </div>
            <div style="clear: both"></div>
            <div class="myheader_threelie" style="color:black">
                <div class="myheader_threelie_son">
                    <span >
                    <?php echo $list['sy']; ?>
                </span><br>账户余额
                </div>
                <div class="myheader_threelie_son">
                    <span >
                    <?php echo $doller; ?>
                </span><br>今日收入
                </div>
                <div class="myheader_threelie_son" style="border: none;">
                    <span>
                    <?php echo $list['tx']; ?>
                </span><br>总提现
                </div>
            </div>
        </div>

        <div class="weui-panel" style="width: 94%;margin: 0 auto;margin-top:15px;">
            <div class="weui-panel__bd">
                <div class="weui-media-box weui-media-box_small-appmsg">
                    <div class="weui-cells">
                        <a class="weui-cell weui-cell_access" href="/index/index/user">
                            <div class="weui-cell__hd"><img src="/index/common/userIcon1.png" alt="" style="width:20px;margin-right:5px;display:block"></div>
                            <div class="weui-cell__bd weui-cell_primary">
                                <p>个人资料</p>
                            </div>
                            <span class="weui-cell__ft"></span>
                        </a>

                    </div>
                </div>
            </div>
        </div>

        <div class="weui-panel" style="width: 94%;margin: 0 auto;margin-top:5px;">
            <div class="weui-panel__bd">
                <div class="weui-media-box weui-media-box_small-appmsg">
                    <div class="weui-cells">
                        <a class="weui-cell weui-cell_access" href="/index/index/team">
                            <div class="weui-cell__hd"><img src="/index/common/userIcon2.png" alt="" style="width:20px;margin-right:5px;display:block"></div>
                            <div class="weui-cell__bd weui-cell_primary">
                                <p>我的团队</p>
                            </div>
                            <span class="weui-cell__ft"></span>
                        </a>
                    </div>
                </div>
            </div>
        </div>





        <div class="weui-panel" style="width: 94%;margin: 0 auto;margin-top:15px;">
            <div class="weui-panel__bd">
                <div class="weui-media-box weui-media-box_small-appmsg">
                    <div class="weui-cells">
                        <a class="weui-cell weui-cell_access" href="/index/index/bank">
                            <div class="weui-cell__hd"><img src="/index/common/userIcon3.png" alt="" style="width:20px;margin-right:5px;display:block"></div>
                            <div class="weui-cell__bd weui-cell_primary">
                                <p>绑定银行卡</p>
                            </div>
                            <span class="weui-cell__ft"></span>
                        </a>

                    </div>
                </div>
            </div>
        </div>

        <div class="weui-panel" style="width: 94%;margin: 0 auto;margin-top:15px;">
            <div class="weui-panel__bd">
                <div class="weui-media-box weui-media-box_small-appmsg">
                    <div class="weui-cells">
                        <a class="weui-cell weui-cell_access" href="/index/index/qianbao">
                            <div class="weui-cell__hd"><img src="/index/common/userIcon4.png" alt="" style="width:20px;margin-right:5px;display:block"></div>
                            <div class="weui-cell__bd weui-cell_primary">
                                <p>钱包</p>
                            </div>
                            <span class="weui-cell__ft"></span>
                        </a>

                    </div>
                </div>
            </div>
        </div>

        <div class="weui-panel" style="width: 94%;margin: 0 auto;margin-top:5px;">
            <div class="weui-panel__bd">
                <div class="weui-media-box weui-media-box_small-appmsg">
                    <div class="weui-cells">
                        <a class="weui-cell weui-cell_access" href="/index/index/caiwu">
                            <div class="weui-cell__hd"><img src="/index/common/userIcon5.png" alt="" style="width:20px;margin-right:5px;display:block"></div>
                            <div class="weui-cell__bd weui-cell_primary">
                                <p>财务管理</p>
                            </div>
                            <span class="weui-cell__ft"></span>
                        </a>
                    </div>
                </div>
            </div>
        </div>


        <div class="page__bd page__bd_spacing" style="margin-top:15px;">
            <a href="/index/login/logout"><div class="weui-btn weui-btn_warn">退出</div></a>
        </div>
        <div class="weui-tabbar-tian" style="height: 70px;clear: both;background-color: #f8f8f8;"></div>

    </div>

</div>


<div class="weui-tabbar">
    <a href="javascript:;" class="weui-tabbar__item js_item weui-bar__item_on" data-id="one">
        <img src="/index/common/tab1.png" alt="" class="weui-tabbar__icon">
        <p class="weui-tabbar__label">首页</p>
    </a>
    <a href="javascript:;" class="weui-tabbar__item js_item" data-id="two" >
        <img src="/index/common/tab2.png" alt="" class="weui-tabbar__icon">
        <p class="weui-tabbar__label">任务中心</p>
    </a>

    <a href="javascript:;" class="weui-tabbar__item js_item" data-id="three" >
        <img src="/index/common/tab3.png" alt="" class="weui-tabbar__icon">
        <p class="weui-tabbar__label">个人中心</p>
    </a>
</div>








<script src="/index/common/example3.js"></script>
<script type="text/javascript" src="/index/common/banner.js"></script>
﻿<script src="/index/common/immersed.js"></script>
<style>
    .container{overflow: auto;}
</style>

</body></html>