<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:82:"D:\phpStudy\PHPTutorial\WWW\gg\public/../application/index\view\yewu\guanggao.html";i:1543222618;}*/ ?>
<!DOCTYPE html>
<!-- saved from url=(0075)http://pexah.cn/app/index.php?i=2&c=entry&p=article&aid=4&m=sz_yi&do=plugin -->
<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

<!-- <link rel="icon" type="image/png" sizes="16x16" href="../addons/sz_yi/template/mobile/style1/static/img/logoico.png"> -->
<title></title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta content="width=device-width,initial-scale=1.0,maximum-scale=1.0,user-scalable=no" id="viewport" name="viewport">
<meta name="format-detection" content="telephone=no">
<link href="/index/guanggao/mobile.css" rel="stylesheet">
<script type="text/javascript" src="/index/guanggao/jquery-1.11.1.min.js.下载"></script>
<script src="/index/guanggao/jweixin-1.0.0.js.下载"></script>
<style>
    .flex{
      display: -webkit-box; /* OLD - iOS 6-, Safari 3.1-6 */
      display: -moz-box; /* OLD - Firefox 19- (buggy but mostly works) */
      display: -ms-flexbox; /* TWEENER - IE 10 */
      display: -webkit-flex; /* NEW - Chrome */
      display: -moz-flex;
      display: -ms-flex;
      display: -o-flex;
      display: flex;  
  }
  .flex_col{
      flex-direction: column;
      -webkit-flex-direction: column;
  }
  .flex_row{
      flex-direction: row;
      -webkit-flex-direction: row;
      
  }
  .flex_center{
      justify-content: center;
      -webkit-justify-content: center;
      align-items: center;
      -webkit-align-items: center;
  }
  .flex_col_center{
      align-items: center;
      align-content: center;
      -webkit-align-items: center;
      -webkit-align-content: center;
  }
  .flex_row_center{
      justify-content: center;
      -webkit-justify-content: center;
  }
  .flex_1{
      flex:1;
      -webkit-flex: 1;
  }
  .flex_between{
      justify-content: space-between;
      -webkit-justify-content: space-between;
  }
  .flex_around{
      justify-content: space-around;
      -webkit-justify-content: space-around;
  }
  .flex_wrap{
      flex-wrap: wrap;
      -moz-flex-wrap: wrap;
      -webkit-flex-wrap: wrap;
  }
  .flex_nowrap{
      flex-wrap: nowrap;
      -moz-flex-wrap: nowrap;
      -webkit-flex-wrap: nowrap;
  }
  html,body{
      width:100%;
      height: 100%;
  }
  .sh_all{
      font-size: 20px;
      width:100%;
      height: 90%;
  }
  /* 顶部 */
.sh_top{
    background: #fff;
    height: 45px;
    color:#fff;
    padding: 0 .5rem;
}
.sh_top_center{
    font-size: 18px;
    color:#000;
}
.sh_top_lf, .sh_top_ri{
    width: 25px;
}
.sh_top_lf img , .sh_top_ri img{
    width: 88%;
}
/* 顶部结束 */
</style>
</head>

<body> 
    <!-- 顶部 -->
    <div class="sh_top flex flex_between">

        <a href="javascript:void(0)" class="sh_top_lf flex flex_col_center" onclick="history.back()">

            <img style="width:20px;" src="/index/guanggao/left_black.png" alt="">

        </a>

        <div class="sh_top_center flex flex_col_center"></div>

        <div class="sh_top_ri flex flex_col_center">

            

        </div>

    </div>
    
    <!-- 顶部结束 -->
    <div class="rich_primary">
        <div class="rich_title">广告投放</div>
        <div class="rich_mate">
            <!--div class="rich_mate_text">2018-10-22</div-->
            <!--div class="rich_mate_text"></div-->
            <a href="javascript:;"><!--div class="rich_mate_text href">发圈传媒总部</div--></a>
        </div>
        <div class="rich_content">
            <section style="margin: 5px auto;white-space: normal;"><section class="btc" style="margin:2em 0 0;padding:.5em 0;max-width:100%;font-family:inherit;font-size:1em;line-height:25px;white-space:normal;background-color:#fff;border-style:solid none none;border-top-width:1px;border-top-color:#f54242;text-decoration:inherit;color:#a6a6a6;box-sizing:border-box!important;word-wrap:break-word!important"><section style="margin:-1.2em 0 0;padding:0;max-width:100%;text-align:center;border:none;line-height:1.4;box-sizing:border-box!important;word-wrap:break-word!important"><span class="bc" style="margin: 0px; padding: 0px; max-width: 100%; font-family: inherit; border-radius: 25px; color: rgb(255, 255, 255); font-size: 1em; text-decoration: inherit; border-color: rgb(112, 216, 255); box-sizing: border-box !important; word-wrap: break-word !important; line-height: 22.4px; text-indent: 28px; background-color: rgb(245, 66, 66);">发圈传媒广告投放中心</span></section></section></section><p style="line-height: 0; text-align: left;"><br></p><p style="text-align: left;"><strong><span style="color: rgb(255, 0, 0); font-size: 14px;">一、发圈传媒是国内专业的广告投放平台，用户所投放的产品广告都是&nbsp;经过平台严厉审核的、产品不能涉及博彩类、棋牌类等违反国家法律法规的产品。</span></strong></p><p style="text-align: left;"><span style="color: rgb(0, 0, 0); font-size: 14px;">二、广告投放具体标准如下：</span></p><p style="text-align: left;"><span style="font-size: 14px;">1、水果类产品广告费用0.55/条，最低15000元起投</span></p><p style="text-align: left;"><span style="font-size: 14px;">2、食品类产品广告费用0.60/条，最低20000元起投</span></p><p style="text-align: left;"><span style="font-size: 14px;">3、茶叶类产品广告费用0.75/条，最低25000元起投</span></p><p style="text-align: left;"><span style="font-size: 14px;">4、保健类产品广告费用0.80/条，最低30000元起投</span></p><p style="text-align: left;"><span style="font-size: 14px;">5、护肤类产品广告费用0.85/条，最低35000元起投</span></p><p style="text-align: left;"><span style="font-size: 14px;">6、电子类产品广告费用0.90/条，最低45000元起投</span></p><p style="text-align: left;"><span style="font-size: 14px;">7、其他类别产品广告费用0.95/条，最低50000元起投</span></p><p style="text-align: left;"><br></p><p style="text-align: left;"><br></p><p style="text-align: left;"><span style="font-size: 14px;">注释：一条广告的意思是一个发圈传媒的会员将广告分享到微信朋友圈，分享的广告产品在会员的朋友圈最少停留两个小时。</span></p><p style="text-align: left;"><span style="font-size: 14px;"><br></span></p><p style="text-align: left;"><span style="font-size: 14px;">您的广告产品将会覆盖10亿朋友圈用户，详情可咨询发圈传媒客服：</span></p><p style="text-align: left; margin-top: 5px;"><span style="font-size: 16px;"><strong>微信客服：18641267070</strong><strong><br></strong></span></p><p style="text-align: left; margin-top: 5px;"><span style="font-size: 16px;"><strong>QQ 客服：18641267070</strong></span></p><section class="awbEditor_info awbEditor_material" style="margin: 0px; padding: 0px; max-width: 100%; color: rgb(62, 62, 62); font-family: &#39;Microsoft YaHei&#39;, Arial, sans-serif; font-variant-ligatures: normal; orphans: 2; white-space: normal; widows: 2; outline: none 0px !important; box-sizing: border-box !important; word-wrap: break-word !important;"><section class="AWBEditor" style="margin: 0px; padding: 0px; outline: none 0px !important; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important;"><p class="" style="margin-top: 0.5em; margin-bottom: 0.5em; padding: 0px; max-width: 100%; min-height: 1em; clear: both; color: rgb(255, 255, 255); text-align: center; line-height: 32px; outline: none 0px !important; box-sizing: border-box !important; word-wrap: break-word !important;"><br></p></section></section><section><p style="margin-top: 0px; margin-bottom: 0px; padding: 0px; max-width: 100%; min-height: 1em; clear: both; color: rgb(62, 62, 62); font-family: &#39;Microsoft YaHei&#39;, Arial, sans-serif; font-variant-ligatures: normal; orphans: 2; white-space: normal; widows: 2; outline: none 0px !important; box-sizing: border-box !important; word-wrap: break-word !important;"><br></p><p><br></p></section>        </div>
        <div class="rich_tool">
                                            </div>
		<!--如果设定的任务总金额显示@phpdb.net-->
		    </div>
    <script type="text/javascript" src="/index/guanggao/swipe.js.下载"></script>
<script type="text/javascript" src="/index/guanggao/swipe.config.js.下载"></script>


</body></html>