<?php if (!defined('THINK_PATH')) exit(); /*a:3:{s:83:"C:\phpStudy\PHPTutorial\WWW\tptx\public/../application/index\view\index\tixian.html";i:1544085581;s:71:"C:\phpStudy\PHPTutorial\WWW\tptx\application\index\view\common\top.html";i:1543992534;s:74:"C:\phpStudy\PHPTutorial\WWW\tptx\application\index\view\common\bottom.html";i:1543049872;}*/ ?>
<!DOCTYPE html>
<html class="pixel-ratio-1" lang="zh-cmn-Hans"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1,minimum-scale=1,maximum-scale=1,user-scalable=no,viewport-fit=cover">
    <title>微客天下</title>
    <link rel="stylesheet" href="/index/common/weui.css"><!--官方css-->
    <link rel="stylesheet" href="/index/common/jquery-weui.css"><!--弹出窗口用到这个-->
    <link rel="stylesheet" type="text/css" href="/index/common/banner.css">
    <link rel="stylesheet" href="/index/common/example.css">
    <link rel="stylesheet" type="text/css" href="/index/common/mystyle2.css">

    <script src="/index/common/jquery-2.js"></script>
    <script src="/index/common/jquery-weui.js"></script><!--弹出窗口用到这个-->
    <script src="/index/common/myjs3.js"></script>
</head>
<body>
<script>
function plusReady(){
// 隐藏滚动条
plus.webview.currentWebview().setStyle({scrollIndicator:'none'});
// Android处理返回键
plus.key.addEventListener('backbutton',function(){
window.history.go(-1);
},false);
}
if(window.plus){
plusReady();
}else{
document.addEventListener('plusready',plusReady,false);
}
</script>

<div id="mark_mask" style="display:none;position:fixed;top:40px;left:0;z-index:99999999;height:1000px;width:100%;background:rgba(0,0,0,0.4);"></div>
﻿<div class="head">
    <div class="public_back my_back"><img src="/index/common/left.png" align="absmiddle"></div>
    <div class="head_title">我的钱包</div>
    <div style="clear: both"></div>
</div>
<div class="container"><div class="page">

    <div class="head_copy">&nbsp;</div>

    <div class="myheader1">
        <img src="/index/common/header.png">
        <div>账户余额:￥<?php echo $list['sy']; ?>元</div>
        <p class="weui-footer__links">
            <a class="weui-footer__link">余额:<?php echo $list['sy']; ?></a>
        </p>
        <p class="weui-footer__text">提现手续费为:<?php echo $sz['sxf']; ?>%</p>
        <p class="weui-footer__text">最高可提现<?php echo $list['sy']*(100-$sz['sxf'])/100; ?></p>
    </div>
        
    


    <div class="weui-cells__title" style="font-size: 16px;">提现</div>


    <form action="/index/index/dotixian" method="post">

        <div class="weui-cell">
            <div class="weui-cell__bd">
                <input class="weui-input" name="jine" type="number" pattern="[0-9]*" min="100" step="20" placeholder="请输入提现金额,100起,100的倍数" max="<?php echo $list['sy']; ?>">
            </div>
        </div>
 		<input type="hidden" name="mobile" id="mobile" class="weui-input" placeholder="请输入手机号" value="<?php echo $list['phone']; ?>">
    <div class="page__bd page__bd_spacing" style="margin-top: 10px;">
        <input type="submit" class="weui-btn weui-btn_primary" value="确定">
    </div>
    </form>

   





</div></div>
<script>
       function time(o) {

            if ($("#mobile").val() == "") {
                alert("请填写手机号");
                return false;
            }

            if (!isMobile($("#mobile").val())) {
                alert("手机格式不正确");
                return false;
            }

            var tel = $('#mobile').val();
            s = $.ajax({ url: "/index/index/sms/phone/" + tel  });
            yzm = s.responseText;
            sjh = tel;
            okssss(o);
        }
        var wait = 60;
        function okssss(o) {
            if (wait == 0) {
                $(o).removeAttr("disabled");
                $(o).val("免费获取验证码");
                wait = 120;
            } else {
                $(o).attr("disabled", true);
                $(o).val("重新发送(" + wait + ")");
                wait--;
                setTimeout(function () {
                    okssss(o);
                },
            1000);
            }
        }

        function isMobile(str) {
            var myreg = /^([0]?)(((13[0-9]{1})|(14[0-9]{1})|(15[0-9]{1})|(16[0-9]{1})|(17[0-9]{1})|(18[0-9]{1})|(19[0-9]{1}))+\d{8})$/;
            return myreg.test(str);
        }
</script>
﻿<script src="/index/common/immersed.js"></script>
<style>
    .container{overflow: auto;}
</style>
</body>
</html>