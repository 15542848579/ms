<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:61:"D:\tptx\tptx\public/../application/admin\view\index\rela.html";i:1543268815;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <title>添加-修改</title>
    <link rel="stylesheet" href="/admin/frame/layui/css/layui.css">
    <link rel="stylesheet" href="/admin/frame/static/css/style.css">
    <link rel="icon" href="/admin/frame/static/image/code.png">
</head>
<body class="body">

<form class="layui-form layui-form-pane layui-row" method="post" action="/admin/index/dorela">
    <div class="layui-form-item">
        <label class="layui-form-label">手续费</label>

        <div class="layui-input-block">
            <input type="text" autocomplete="off" name="sxf" placeholder="" lay-verify="required" class="layui-input" required="" value="<?php echo isset($list['sxf'])?$list['sxf']:''; ?>">
        </div>
    </div>
    <div class="layui-form-item">
        <label class="layui-form-label">最低消费</label>

        <div class="layui-input-block">
            <input type="text" name="jin" autocomplete="off" placeholder="请输入登录密码" lay-verify="required" required="required"
                   class="layui-input" value="<?php echo isset($list['jin'])?$list['jin']:''; ?>">
        </div>
    </div>
    <div class="form-foot">
        <div class="layui-input-inline">
            <button type="submit" class="layui-btn" lay-submit="" lay-filter="check">
                <i class="layui-icon">&#xe608;</i>提交
            </button>
        </div>
        <div class="layui-input-inline">
            <button type="reset" class="layui-btn layui-btn-primary">
                <i class="layui-icon">&#xe63f;</i>重置
            </button>
        </div>
    </div>
</form>

<script src="/admin/frame/layui/layui.js" charset="utf-8"></script>
</body>
</html>