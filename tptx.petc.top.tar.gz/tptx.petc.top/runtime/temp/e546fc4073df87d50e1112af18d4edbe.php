<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:60:"D:\tptx\tptx\public/../application/admin\view\index\res.html";i:1544021344;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <title>提现审核</title>
    <link rel="stylesheet" href="/admin/frame/layui/css/layui.css">
    <link rel="stylesheet" href="/admin/frame/static/css/style.css">
    <link rel="icon" href="/admin/frame/static/image/code.png">
</head>
<body class="body">

    <div class="layui-form-item">
        <label class="layui-form-label">用户ID</label>

        <div class="layui-input-block">
            <div type="text" name="title" autocomplete="off" lay-verify="required"
                   class="layui-input"><?php echo $user['id']; ?></div>
        </div>
    </div>
     <div class="layui-form-item">
        <label class="layui-form-label">用户名</label>

        <div class="layui-input-block">
            <div type="text" name="sl" autocomplete="off" placeholder="请输入数量" lay-verify="required"
                   class="layui-input"><?php echo $user['username']; ?></div>
        </div>
    </div>
    <div class="layui-form-item">
        <label class="layui-form-label">用户名</label>

        <div class="layui-input-block">
            <div type="text" name="sl" autocomplete="off" placeholder="请输入数量" lay-verify="required"
                   class="layui-input"><?php echo $user['bankname']; ?></div>
        </div>
    </div>
     <div class="layui-form-item">
        <label class="layui-form-label">提款方式</label>

        <div class="layui-input-block">
            <div type="text" name="je" autocomplete="off"  lay-verify="required"
                   class="layui-input"><?php echo $user['bank']; ?></div>
        </div>
    </div>
    <div class="layui-form-item">
        <label class="layui-form-label">提款账号</label>

        <div class="layui-input-block">
            <div type="text" name="ysl" autocomplete="off"  lay-verify="required"
                   class="layui-input"><?php echo $user['banknum']; ?></div>
        </div>
    </div>
    <div class="layui-form-item">
        <label class="layui-form-label">银行行号</label>

        <div class="layui-input-block">
            <div type="text" name="ysl" autocomplete="off"  lay-verify="required"
                   class="layui-input"><?php echo $user['bankhanghao']; ?></div>
        </div>
    </div>
    <div class="layui-form-item">
        <label class="layui-form-label">提现的金额</label>

        <div class="layui-input-block">
            <div type="text" name="ggdj" autocomplete="off"  lay-verify="required"
                   class="layui-input"><?php echo $list['price']; ?></div>
        </div>
    </div>
    <input type="hidden" name="tx" value="<?php echo $list['id']; ?>">
    <div class="form-foot">
        <div class="layui-input-inline">
            <a href="/admin/index/reds/id/<?php echo $list['id']; ?>/type/1" class="layui-btn" lay-submit="" lay-filter="check">
                <i class="layui-icon">&#xe608;</i>已发放
            </a>
        </div>
        <div class="layui-input-inline">
            <a href="/admin/index/reds/id/<?php echo $list['id']; ?>/type/2" class="layui-btn" lay-submit="" lay-filter="check">
                <i class="layui-icon">&#xe608;</i>不发放
            </a>
        </div>
    </div>

<script src="/admin/frame/layui/layui.js" charset="utf-8"></script>
</body>
</html>