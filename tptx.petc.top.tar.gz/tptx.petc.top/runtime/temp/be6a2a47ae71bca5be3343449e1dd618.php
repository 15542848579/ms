<?php if (!defined('THINK_PATH')) exit(); /*a:3:{s:79:"D:\phpStudy\PHPTutorial\tptx\public/../application/index\view\yewu\erweima.html";i:1543587807;s:67:"D:\phpStudy\PHPTutorial\tptx\application\index\view\common\top.html";i:1543583704;s:70:"D:\phpStudy\PHPTutorial\tptx\application\index\view\common\bottom.html";i:1543049873;}*/ ?>
<!DOCTYPE html>
<html class="pixel-ratio-1" lang="zh-cmn-Hans"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1,minimum-scale=1,maximum-scale=1,user-scalable=no,viewport-fit=cover">
    <title>同屏天下</title>
    <link rel="stylesheet" href="/index/common/weui.css"><!--官方css-->
    <link rel="stylesheet" href="/index/common/jquery-weui.css"><!--弹出窗口用到这个-->
    <link rel="stylesheet" type="text/css" href="/index/common/banner.css">
    <link rel="stylesheet" href="/index/common/example.css">
    <link rel="stylesheet" type="text/css" href="/index/common/mystyle2.css">

    <script src="/index/common/jquery-2.js"></script>
    <script src="/index/common/jquery-weui.js"></script><!--弹出窗口用到这个-->
    <script src="/index/common/myjs3.js"></script>
</head>
<body>
<script>
function plusReady(){
// 隐藏滚动条
plus.webview.currentWebview().setStyle({scrollIndicator:'none'});
// Android处理返回键
plus.key.addEventListener('backbutton',function(){
window.history.go(-1);
},false);
}
if(window.plus){
plusReady();
}else{
document.addEventListener('plusready',plusReady,false);
}
</script>

<div id="mark_mask" style="display:none;position:fixed;top:40px;left:0;z-index:99999999;height:1000px;width:100%;background:rgba(0,0,0,0.4);"></div>

<div class="head">
    <div class="public_back my_back"><img src="/index/common/left.png" align="absmiddle"></div>
    <div class="head_title">同屏天下</div>
    <div style="clear: both"></div>
</div>
<div class="container">
    <div class="page" style="background: #ffffff">



<style> 

.img1{position:absolute; z-index:0;}
.img2{position:absolute; z-index:10;top:405px;width: 26%;left: 37%;height: 152px;} 
/* DIV背景颜色为蓝色 */ 
</style> 

    <div class="head_copy">&nbsp;</div>
    <div style="height: 900px;" >
<img class="img1" src="/index/common/erweima.jpg" width="100%" height="900px">
<img class="img2" src="/index/yewu/view" >
</div> 
   

    <script>
        $('.temp_reg img').css('width','100%');
        //$('.temp_reg img').css('height',$(window).height()-50);
    </script>



    <article class="weui-article">
        <div class="btn"  style="width: 65%;margin: 0 auto;line-height: 30px;background: red;text-align: center;color: #ffffff;border-radius: 25px;" data-clipboard-action="copy" data-clipboard-target="#bar">
            <a href="javascript:void(0);" class="weui-cell weui-cell_access weui-cell_link">
                <div class="weui-cell__bd" style="color: #ffffff;font-size: 18px;">点击复制推广链接</div>
            </a>
          </div>

        <section>
            <h2 class="title" id="bar" style="color: #ffffff"> <?php echo $list; ?></h2>
        </section>
    </article>


</div></div>
<script type="text/javascript" src="/index/common/clipboard.js"></script>
<script>
    var clipboard = new Clipboard('.btn');
    clipboard.on('success', function(e) {
        console.info('Action:', e.action);
        console.info('Text:', e.text);
        console.info('Trigger:', e.trigger);
        $.toast("复制成功");
        e.clearSelection();
    });
    clipboard.on('error', function(e) {
        console.error('Action:', e.action);
        console.error('Trigger:', e.trigger);
    });
</script>
﻿<script src="/index/common/immersed.js"></script>
<style>
    .container{overflow: auto;}
</style>
</body>
</html>