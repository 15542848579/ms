<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:81:"D:\phpStudy\PHPTutorial\WWW\gg\public/../application/index\view\login\wangji.html";i:1543043927;}*/ ?>
<!DOCTYPE html>
<html class="pixel-ratio-1" lang="zh-cmn-Hans"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">


    <meta name="viewport" content="width=device-width,initial-scale=1,minimum-scale=1,maximum-scale=1,user-scalable=no,viewport-fit=cover">
    <title>微广告</title>
    <link rel="stylesheet" href="/index/common/weui.css">
    <link rel="stylesheet" href="/index/common/jquery-weui.css">
    <link rel="stylesheet" type="text/css" href="/index/common/banner.css">
    <link rel="stylesheet" href="/index/common/example.css">
    <link rel="stylesheet" type="text/css" href="/index/common/mystyle2.css">
    <script src="/index/common/jquery-2.js"></script>
    <script src="/index/common/jquery-weui.js"></script><!--弹出窗口用到这个-->
    <script src="/index/common/myjs3.js"></script>
</head>
<body>
<script>
function plusReady(){
// 隐藏滚动条
plus.webview.currentWebview().setStyle({scrollIndicator:'none'});
// Android处理返回键
plus.key.addEventListener('backbutton',function(){
window.history.go(-1);
},false);
}
if(window.plus){
plusReady();
}else{
document.addEventListener('plusready',plusReady,false);
}


</script>
<div id="mark_mask" style="display:none;position:fixed;top:40px;left:0;z-index:99999999;height:1000px;width:100%;background:rgba(0,0,0,0.4);"></div>
<div class="container">
    <article class="weui-article">
        <h1 class="findmimatitle">找回密码</h1>
    </article>

    <form id="getforForm" method="post">
        <div class="weui-cell">
            <input type="text" class="weui-input" name="username" id="mobile" placeholder="请输入手机号码">
        </div>
        <div class="weui-cell">
             <input type="password" class="weui-input" name="password" placeholder="请输入新密码">
        </div>
        <div class="weui-cell">

            <div class="weui-cell__bd">
                 <input type="text" class="weui-input" name="yzmcode" placeholder="验证码">
            </div>
            <div class="weui-cell__ft">
                <div class="yzmbutton" onclick="time(this)" id="gettxyzmb">点击获取</div>
            </div>
        </div>

        <div class="page__bd page__bd_spacing">
            <div onclick="forgetCodeQuery()" class="weui-btn weui-btn_primary">确定</div>
        </div>
        <div style="clear: both;height:10px;"></div>
        <p class="weui-footer">
        </p><div style="text-align: center;" class="my_back">返回上级</div>
        <div c="" style="text-align: center;" id="redata" class="redata">&nbsp;</div>
        <p></p>
    </form>
</div>
<script>
       function time(o) {

            if ($("#mobile").val() == "") {
                alert("请填写手机号");
                return false;
            }

            if (!isMobile($("#mobile").val())) {
                alert("手机格式不正确");
                return false;
            }

            var tel = $('#mobile').val();
            s = $.ajax({ url: "/index/login/sms/phone/" + tel  });
            yzm = s.responseText;
            sjh = tel;
            okssss(o);
        }
        var wait = 60;
        function okssss(o) {
            if (wait == 0) {
                $(o).removeAttr("disabled");
                $(o).val("免费获取验证码");
                wait = 120;
            } else {
                $(o).attr("disabled", true);
                $(o).val("重新发送(" + wait + ")");
                wait--;
                setTimeout(function () {
                    okssss(o);
                },
            1000);
            }
        }

        function isMobile(str) {
            var myreg = /^([0]?)(((13[0-9]{1})|(14[0-9]{1})|(15[0-9]{1})|(16[0-9]{1})|(17[0-9]{1})|(18[0-9]{1})|(19[0-9]{1}))+\d{8})$/;
            return myreg.test(str);
        }
</script>

﻿<script src="/index/common/immersed.js"></script>
<style>
    .container{overflow: auto;}
</style>

</body></html>