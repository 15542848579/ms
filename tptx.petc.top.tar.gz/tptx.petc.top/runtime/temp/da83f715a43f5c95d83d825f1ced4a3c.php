<?php if (!defined('THINK_PATH')) exit(); /*a:3:{s:63:"D:\tptx\tptx\public/../application/index\view\yewu\huiyuan.html";i:1544087820;s:51:"D:\tptx\tptx\application\index\view\common\top.html";i:1543992534;s:54:"D:\tptx\tptx\application\index\view\common\bottom.html";i:1543049872;}*/ ?>
<!DOCTYPE html>
<html class="pixel-ratio-1" lang="zh-cmn-Hans"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1,minimum-scale=1,maximum-scale=1,user-scalable=no,viewport-fit=cover">
    <title>微客天下</title>
    <link rel="stylesheet" href="/index/common/weui.css"><!--官方css-->
    <link rel="stylesheet" href="/index/common/jquery-weui.css"><!--弹出窗口用到这个-->
    <link rel="stylesheet" type="text/css" href="/index/common/banner.css">
    <link rel="stylesheet" href="/index/common/example.css">
    <link rel="stylesheet" type="text/css" href="/index/common/mystyle2.css">

    <script src="/index/common/jquery-2.js"></script>
    <script src="/index/common/jquery-weui.js"></script><!--弹出窗口用到这个-->
    <script src="/index/common/myjs3.js"></script>
</head>
<body>
<script>
function plusReady(){
// 隐藏滚动条
plus.webview.currentWebview().setStyle({scrollIndicator:'none'});
// Android处理返回键
plus.key.addEventListener('backbutton',function(){
window.history.go(-1);
},false);
}
if(window.plus){
plusReady();
}else{
document.addEventListener('plusready',plusReady,false);
}
</script>

<div id="mark_mask" style="display:none;position:fixed;top:40px;left:0;z-index:99999999;height:1000px;width:100%;background:rgba(0,0,0,0.4);"></div>
<div class="head">
    <div class="public_back my_back"><img src="/index/common/left.png" align="absmiddle"></div>
    <div class="head_title">微客天下</div>
    <div style="clear: both"></div>
</div>
<div class="container"><div class="page">


    <div class="head_copy">&nbsp;</div>

    <div class="temp_reg"><img src="/index/common/zfb.png" alt="" style="width: 100%;"></div>
    <script>
        $('.temp_reg img').css('width','100%');
    </script>

    <form action="/index/yewu/dohuiyuan" method="post" onsubmit="return tankuang(this)" id="form">
    <div class="weui-cells__title" style="font-size: 16px;">级别</div>
    <div class="weui-cells weui-cells_radio">
        <label class="weui-cell weui-check__label">
            <div class="weui-cell__bd">
                <p>99元(高级)</p>
            </div>
            <div class="weui-cell__ft">
                <input type="radio" class="weui-check" name="buyUser" value="1" checked="checked">
                <span class="weui-icon-checked"></span>
            </div>
        </label>
        <label class="weui-cell weui-check__label">
            <div class="weui-cell__bd">
                <p>999元(高级)</p>
            </div>
            <div class="weui-cell__ft">
                <input type="radio" name="buyUser" class="weui-check" value="2">
                <span class="weui-icon-checked"></span>
            </div>
        </label>
    </div>

    <div class="weui-cells__title" style="font-size: 16px;">支付方式</div>

    <div class="weui-cells weui-cells_radio">
  <!--       <label class="weui-cell weui-check__label">
            <div class="weui-cell__bd">
                <p>支付宝</p>
            </div>
            <div class="weui-cell__ft">
                <input type="radio" class="weui-check" name="payStyle" value="1" checked="checked">
                <span class="weui-icon-checked"></span>
            </div>
        </label> -->
        <label class="weui-cell weui-check__label">
            <div class="weui-cell__bd">
                <p>银行卡</p>
            </div>
            <div class="weui-cell__ft">
                <input type="radio" name="payStyle" class="weui-check" value="2" checked="checked">
                <span class="weui-icon-checked"></span>
            </div>
        </label>
       <!--  <label class="weui-cell weui-check__label">
            <div class="weui-cell__bd">
                <p>余额支付(您的余额:<?php echo $list['sy']; ?>元)</p>
            </div>
            <div class="weui-cell__ft">
                <input type="radio" name="payStyle" class="weui-check" value="3">
                <span class="weui-icon-checked"></span>
            </div>
        </label> -->

    </div>



    <div class="page__bd page__bd_spacing"  style="margin-top: 10px;margin-bottom: 30px">
        <input type="submit" value="确定" class="weui-btn weui-btn_primary">
    </div>
</form>

</div></div>
<script type="text/javascript">
    function tankuang(o) {
            var msg = confirm("平台入驻协议书：\n甲方：大连翼网科技有限公司\n乙方：本平台注册用户\n乙方在甲方微客天下APP注册。成为甲方平台免费注册用户，免费用户不能领取任务赚钱平台广告佣金。只有缴纳平台入驻费后才能领取任务赚取广告佣金。平台入驻费一旦缴纳不作退还。\n平台具体入驻费如下：\n1.    缴纳99元人民币平台入驻费成为普通会员。\n2.    缴纳999元人民币平台入驻费成为本平台高级会员。\n3.    平台根据会员级别不同，乙方赚取的广告佣金将不同，缴纳平台入驻费后，就可以每天从本平台领取最多为两个的任务发布微信朋友圈，通过发布微信朋友圈完成任务来赚取广告佣金。\n乙方如已知晓上述条款，点击确认按钮，将跳转缴纳平台入驻费支付页面。")
            if(msg == true){
                return true;
            }else{
                return false;
            }
           
    }
</script>
﻿<script src="/index/common/immersed.js"></script>
<style>
    .container{overflow: auto;}
</style>
</body>
</html>