<?php if (!defined('THINK_PATH')) exit(); /*a:3:{s:79:"D:\phpStudy\PHPTutorial\WWW\gg\public/../application/index\view\yewu\index.html";i:1543084016;s:69:"D:\phpStudy\PHPTutorial\WWW\gg\application\index\view\common\top.html";i:1543079499;s:72:"D:\phpStudy\PHPTutorial\WWW\gg\application\index\view\common\bottom.html";i:1543049873;}*/ ?>
<!DOCTYPE html>
<html class="pixel-ratio-1" lang="zh-cmn-Hans"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1,minimum-scale=1,maximum-scale=1,user-scalable=no,viewport-fit=cover">
    <title>微广告</title>
    <link rel="stylesheet" href="/index/common/weui.css"><!--官方css-->
    <link rel="stylesheet" href="/index/common/jquery-weui.css"><!--弹出窗口用到这个-->
    <link rel="stylesheet" type="text/css" href="/index/common/banner.css">
    <link rel="stylesheet" href="/index/common/example.css">
    <link rel="stylesheet" type="text/css" href="/index/common/mystyle2.css">

    <script src="/index/common/jquery-2.js"></script>
    <script src="/index/common/jquery-weui.js"></script><!--弹出窗口用到这个-->
    <script src="/index/common/myjs3.js"></script>
</head>
<body>
<script>
function plusReady(){
// 隐藏滚动条
plus.webview.currentWebview().setStyle({scrollIndicator:'none'});
// Android处理返回键
plus.key.addEventListener('backbutton',function(){
window.history.go(-1);
},false);
}
if(window.plus){
plusReady();
}else{
document.addEventListener('plusready',plusReady,false);
}
</script>

<div id="mark_mask" style="display:none;position:fixed;top:40px;left:0;z-index:99999999;height:1000px;width:100%;background:rgba(0,0,0,0.4);"></div>
﻿<div class="head">
    <div class="public_back my_back"><img src="/index/common/left.png" align="absmiddle"></div>
    <div class="head_title">微广告</div>
    <div style="clear: both"></div>
</div>
<div class="container">
    <div class="head_copy">&nbsp;</div>
    <!--<p class="redIntro">加入微广告,开启躺赚人生,如何发圈赚佣</p>-->

    <!--<div style="clear: both"></div>-->

    <!--<div class="tongPadding">-->
    <!--<ul class="time-vertical">-->
        <!--<li><b></b><span>1</span><a href="javascript:void(0)">注册成为会员</a></li>-->
        <!--<li><b></b><span>2</span><a href="javascript:void(0)">支付99元成为VIP</a></li>-->
        <!--<li><b></b><span>3</span><a href="javascript:void(0)">【任务中心】领取任务发朋友圈保留两小时</a></li>-->
        <!--<li><b></b><span>4</span><a href="javascript:void(0)">【提交任务】按照任务模板截图上传</a></li>-->
        <!--<li><b></b><span>5</span><a href="javascript:void(0)">赚取8元/天佣金</a></li>-->
    <!--</ul>-->
    <!--</div>-->
    <div class="conentPage" style="padding-top: 0px;"><img src="/index/common/5beccc842d971.png" alt="">    </div>

</div>
﻿<script src="/index/common/immersed.js"></script>
<style>
    .container{overflow: auto;}
</style>
</body>
</html>
