<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:84:"C:\phpStudy\PHPTutorial\WWW\tptx\public/../application/admin\view\index\takeone.html";i:1544020390;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <title>添加-修改</title>
    <link rel="stylesheet" href="../frame/layui/css/layui.css">
    <link rel="stylesheet" href="../frame/static/css/style.css">
    <link rel="icon" href="../frame/static/image/code.png">
</head>
<body class="body">

<form class="layui-form layui-form-pane layui-row" method="post" action="/admin/index/doone">
    <div class="layui-form-item">
        <label class="layui-form-label">登录账号</label>

        <div class="layui-input-block">
            <input type="text" name="username" autocomplete="off" placeholder="请输入登录账号" lay-verify="required" class="layui-input" required="required">
        </div>
    </div>
    <div class="layui-form-item">
        <label class="layui-form-label">登录密码</label>

        <div class="layui-input-block">
            <input type="text" name="password" autocomplete="off" placeholder="请输入登录密码" lay-verify="required" required="required"
                   class="layui-input">
        </div>
    </div>
    <div class="layui-form-item">
        <label class="layui-form-label">手机</label>

        <div class="layui-input-block">
            <input type="number" name="phone" autocomplete="off" placeholder="请输入手机" lay-verify="required" required="required" class="layui-input">
        </div>
    </div>
    <div class="layui-form-item">
        <label class="layui-form-label">银行</label>

        <div class="layui-input-block">
            <input type="text" name="bank" autocomplete="off" placeholder="可不填" lay-verify="required"
                   class="layui-input">
        </div>
    </div>
    <div class="layui-form-item">
        <label class="layui-form-label">银行卡号</label>

        <div class="layui-input-block">
            <input type="text" name="banknum" autocomplete="off" placeholder="可不填" lay-verify="required"
                   class="layui-input">
        </div>
    </div>
    <div class="layui-form-item">
        <label class="layui-form-label">具体支行</label>

        <div class="layui-input-block">
            <input type="text" name="bankxi" autocomplete="off" placeholder="可不填" lay-verify="required"
                   class="layui-input">
        </div>
    </div>
    <div class="layui-form-item">
        <label class="layui-form-label">持卡人姓名</label>

        <div class="layui-input-block">
            <input type="text" name="bankname" autocomplete="off" placeholder="可不填" lay-verify="required"
                   class="layui-input">
        </div>
    </div>
    <div class="layui-form-item">
        <label class="layui-form-label">开户省份</label>

        <div class="layui-input-block">
            <input type="text" name="banksheng" autocomplete="off" placeholder="可不填" lay-verify="required"
                   class="layui-input">
        </div>
    </div>
    <div class="layui-form-item">
        <label class="layui-form-label">开户市区</label>

        <div class="layui-input-block">
            <input type="text" name="bankshi" autocomplete="off" placeholder="可不填" lay-verify="required"
                   class="layui-input">
        </div>
    </div>
    <div class="layui-form-item">
        <label class="layui-form-label">会员等级</label>

        <div class="layui-input-block">
            <input type="text" name="level" autocomplete="off" placeholder="0,1,2" lay-verify="required"
                   class="layui-input">
        </div>
    </div>
    <div class="form-foot">
        <div class="layui-input-inline">
            <button type="submit" class="layui-btn" lay-submit="" lay-filter="check">
                <i class="layui-icon">&#xe608;</i>提交
            </button>
        </div>
        <div class="layui-input-inline">
            <button type="reset" class="layui-btn layui-btn-primary">
                <i class="layui-icon">&#xe63f;</i>重置
            </button>
        </div>
    </div>
</form>

<script src="../frame/layui/layui.js" charset="utf-8"></script>
</body>
</html>