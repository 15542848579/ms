<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:80:"C:\phpStudy\PHPTutorial\WWW\tptx\public/../application/admin\view\index\pay.html";i:1543268510;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <title>Data-Table 表格</title>
    <link rel="stylesheet" href="../frame/layui/css/layui.css">
    <!--<link rel="stylesheet" href="http://cdn.datatables.net/1.10.13/css/jquery.dataTables.min.css">-->
    <link rel="stylesheet" href="../frame/static/css/style.css">
    <link rel="icon" href="../frame/static/image/code.png">
</head>
<body>

<div class="admin-main">
    <blockquote class="layui-elem-quote quoteBox">
        <form class="layui-form" action="/admin/index/withdrawlist" method="post">
            <div class="layui-inline">
                <div class="layui-input-inline">
                    <input name="keyword" value="" placeholder="请输入搜索关键词"
                           class="layui-input searchVal" type="text">
                </div>
            </div>
            <div class="layui-inline">
                <button class="layui-btn layui-btn-sm">
                    <i class="layui-icon">&#xe615;</i> 搜索
                </button>
            </div>
            <div class="layui-inline">
                <a href="javascript:location.reload();" class="layui-btn layui-btn-normal layui-btn-sm">
                    <i class="layui-icon">&#x1002;</i> 刷新
                </a>
            </div>
        </form>
    </blockquote>
    <fieldset class="layui-elem-field">
        <legend>分销表，暂不给设置</legend>
        <div class="layui-field-box layui-form">
            <table class="layui-table admin-table" lay-even lay-skin="row">
                <thead>
                <?php if(!(empty($list) || (($list instanceof \think\Collection || $list instanceof \think\Paginator ) && $list->isEmpty()))): ?>
                <tr>
                    <th>可以领取次数</th>
                    <th>当前用户等级</th>
                    <th>上级用户等级</th>
                    <th>二级上级用户等级</th>
                    <th>当前用户广告价格</th>
                    <th>上级用户广告价格</th>
                    <th>二级上级广告价格</th>
                    <th>上级用户推荐</th>
                    <th>二级上级用户推荐</th>
                </tr>
                <?php endif; ?>
                </thead>
                <tbody>
                <?php if(is_array($list) || $list instanceof \think\Collection || $list instanceof \think\Paginator): $i = 0; $__LIST__ = $list;if( count($__LIST__)==0 ) : echo "没有值" ;else: foreach($__LIST__ as $key=>$row): $mod = ($i % 2 );++$i;?>
                <tr class="checkbox">

                    <td>
                        <?php echo $row['ci']; ?>
                    </td>
                    <td>
                        <?php echo $row['level']; ?>
                    </td>
                    <td>
                        <?php echo $row['l1']; ?>
                    </td>
                    <td>
                        <?php echo $row['l2']; ?>
                    </td>
                    <td>
                        <?php echo $row['price']; ?>
                    </td>
                    <td>
                        <?php echo $row['s1']; ?>
                    </td>
                    <td>
                        <?php echo $row['s2']; ?>
                    </td>
                    <td>
                        <?php echo $row['t1']; ?>
                    </td>
                    <td>
                        <?php echo $row['t2']; ?>
                    </td>
                </tr>
                <?php endforeach; endif; else: echo "没有值" ;endif; ?>
                </tbody>
            </table>
        </div>


    </fieldset>

</div>
<script type="text/javascript" src="../js/jquery.js"></script>
<script type="text/javascript" src="../frame/layui/layui.js"></script>
<script type="text/javascript" src="../js/admin.js"></script>
<script type="text/javascript" src="../js/index.js"></script>
</body>
</html>