<?php if (!defined('THINK_PATH')) exit(); /*a:3:{s:77:"D:\phpStudy\PHPTutorial\WWW\gg\public/../application/index\view\renwu\ad.html";i:1543311812;s:69:"D:\phpStudy\PHPTutorial\WWW\gg\application\index\view\common\top.html";i:1543079499;s:72:"D:\phpStudy\PHPTutorial\WWW\gg\application\index\view\common\bottom.html";i:1543049873;}*/ ?>
<!DOCTYPE html>
<html class="pixel-ratio-1" lang="zh-cmn-Hans"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1,minimum-scale=1,maximum-scale=1,user-scalable=no,viewport-fit=cover">
    <title>微广告</title>
    <link rel="stylesheet" href="/index/common/weui.css"><!--官方css-->
    <link rel="stylesheet" href="/index/common/jquery-weui.css"><!--弹出窗口用到这个-->
    <link rel="stylesheet" type="text/css" href="/index/common/banner.css">
    <link rel="stylesheet" href="/index/common/example.css">
    <link rel="stylesheet" type="text/css" href="/index/common/mystyle2.css">

    <script src="/index/common/jquery-2.js"></script>
    <script src="/index/common/jquery-weui.js"></script><!--弹出窗口用到这个-->
    <script src="/index/common/myjs3.js"></script>
</head>
<body>
<script>
function plusReady(){
// 隐藏滚动条
plus.webview.currentWebview().setStyle({scrollIndicator:'none'});
// Android处理返回键
plus.key.addEventListener('backbutton',function(){
window.history.go(-1);
},false);
}
if(window.plus){
plusReady();
}else{
document.addEventListener('plusready',plusReady,false);
}
</script>

<div id="mark_mask" style="display:none;position:fixed;top:40px;left:0;z-index:99999999;height:1000px;width:100%;background:rgba(0,0,0,0.4);"></div>
﻿﻿<div class="head">
    <div class="public_back my_back"><img src="/index/common/left.png" align="absmiddle"></div>
    <div class="head_title">任务详情</div>
    <div style="clear: both"></div>
</div>

<div class="container"><div class="page">
    <div class="head_copy">&nbsp;</div>

    <div class="weui-panel weui-panel_access">
        <div class="weui-panel__hd"><h4 class="weui-media-box__title">【<?php switch($list['level']): case "0": ?>初级	<?php break; case "1": ?>中级<?php break; case "2": ?>高级<?php break; endswitch; ?>任务】<?php echo $list['title']; ?></h4></div>
        <div class="weui-panel__bd">
            <div class="weui-media-box weui-media-box_text">
                <p class="weui-media-box__desc">请将以下文案及图片发布到您的朋友圈(长按图片可复制图片到手机)</p>
            </div>
            <div class="weui-media-box weui-media-box_text">

                <p class="weui-media-box__desc">
                <textarea style=" outline:none;  border:none;width: 100%;height: 70px;" id="bar" autocomplete="off" autocorrect="off" autocapitalize="off" spellcheck="false">【<?php echo $list['title']; ?>】<?php echo $list['ad']; ?></textarea>

            </p>
            </div>
        </div>
        <div class="weui-panel__ft btn" data-clipboard-action="copy" data-clipboard-target="#bar">
            <a href="javascript:void(0);" class="weui-cell weui-cell_access weui-cell_link">
                <div style="text-align: center;border: 1px solid red;width: 100px;margin: 0 auto;line-height: 30px;color: red;border-radius: 3px;">复制文案</div>
            </a>
        </div>
    </div>

    <div class="taskimgdiv">
        <div class="weui-panel__hd"><h4 class="weui-media-box__title">图片信息</h4>
            <img src="<?php echo $list['img']; ?>" onclick="createDownload(this)">        </div>
    </div>

    <?php if($list['img2']): ?>
    <div class="taskimgdiv">
        <div class="weui-panel__hd">
            <img src="<?php echo $list['img2']; ?>" onclick="createDownload(this)">        </div>
    </div>
    <?php endif; ?>
    <div class="page__bd page__bd_spacing" style="margin-top: 10px;margin-bottom: 20px;">
        <a href="/index/renwu/doad/id/<?php echo $list['id']; ?>" data-id="<?php echo $list['id']; ?>" class="weui-btn weui-btn_primary">领取任务</a>
    </div>






</div></div>
<script type="text/javascript" src="/index/common/clipboard.js"></script>
<script>
    var clipboard = new Clipboard('.btn');
    clipboard.on('success', function(e) {
        console.info('Action:', e.action);
        console.info('Text:', e.text);
        console.info('Trigger:', e.trigger);
        $.toast("复制成功");
        e.clearSelection();
    });
    clipboard.on('error', function(e) {
        console.error('Action:', e.action);
        console.error('Trigger:', e.trigger);
    });
</script>

﻿<script src="/index/common/immersed.js"></script>
<style>
    .container{overflow: auto;}
</style>
</body>
</html>