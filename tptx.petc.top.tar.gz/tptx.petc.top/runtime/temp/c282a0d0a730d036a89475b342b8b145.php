<?php if (!defined('THINK_PATH')) exit(); /*a:3:{s:63:"D:\tptx\tptx\public/../application/index\view\renwu\tijiao.html";i:1543735250;s:51:"D:\tptx\tptx\application\index\view\common\top.html";i:1543992535;s:54:"D:\tptx\tptx\application\index\view\common\bottom.html";i:1543049873;}*/ ?>
<!DOCTYPE html>
<html class="pixel-ratio-1" lang="zh-cmn-Hans"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1,minimum-scale=1,maximum-scale=1,user-scalable=no,viewport-fit=cover">
    <title>微客天下</title>
    <link rel="stylesheet" href="/index/common/weui.css"><!--官方css-->
    <link rel="stylesheet" href="/index/common/jquery-weui.css"><!--弹出窗口用到这个-->
    <link rel="stylesheet" type="text/css" href="/index/common/banner.css">
    <link rel="stylesheet" href="/index/common/example.css">
    <link rel="stylesheet" type="text/css" href="/index/common/mystyle2.css">

    <script src="/index/common/jquery-2.js"></script>
    <script src="/index/common/jquery-weui.js"></script><!--弹出窗口用到这个-->
    <script src="/index/common/myjs3.js"></script>
</head>
<body>
<script>
function plusReady(){
// 隐藏滚动条
plus.webview.currentWebview().setStyle({scrollIndicator:'none'});
// Android处理返回键
plus.key.addEventListener('backbutton',function(){
window.history.go(-1);
},false);
}
if(window.plus){
plusReady();
}else{
document.addEventListener('plusready',plusReady,false);
}
</script>

<div id="mark_mask" style="display:none;position:fixed;top:40px;left:0;z-index:99999999;height:1000px;width:100%;background:rgba(0,0,0,0.4);"></div>
﻿<div class="head">
    <div class="public_back my_back"><img src="/index/common/left.png" align="absmiddle"></div>
    <div class="head_title">任务列表</div>
    <div style="clear: both"></div>
</div>

<div class="container"><div class="page">

    <div class="head_copy">&nbsp;</div>
    <?php if(is_array($list) || $list instanceof \think\Collection || $list instanceof \think\Paginator): $i = 0; $__LIST__ = $list;if( count($__LIST__)==0 ) : echo "没有订单" ;else: foreach($__LIST__ as $key=>$row): $mod = ($i % 2 );++$i;?>
    <a href="/index/renwu/qtj/id/<?php echo $row['id']; ?>" class="weui-media-box weui-media-box_appmsg weui-cell weui-cell_access">
        <div class="weui-media-box__hd">
            <img class="weui-media-box__thumb" src="<?php echo $row['img']; ?>" alt="">
        </div>
        <div class="weui-media-box__bd">
            <div style="color: gray;font-size: 14px;">【<?php switch($row['level']): case "0": ?>游客	<?php break; case "1": ?>会员<?php break; endswitch; ?>任务】<?php echo $row['title']; ?></div>
            <p style="color: gray;font-size: 14px;">领取时间:<?php echo date('Y-m-d H:i:s',$row['ltime']); ?></p>

        </div>
        <span class="weui-cell__ft">
            <div style="color: gray;font-size: 14px;margin-right: 10px;color: red;">￥<?php echo $row['price']; ?></div>
            <p style="color: gray;font-size: 14px;">【<?php switch($row['level']): case "0": ?>游客<?php break; case "1": ?>会员<?php break; endswitch; ?>】</p>
        </span>
    </a>
    <?php endforeach; endif; else: echo "没有订单" ;endif; ?>


</div>
<?php echo $page; ?>
</div>

﻿<script src="/index/common/immersed.js"></script>
<style>
    .container{overflow: auto;}
</style>
</body>
</html>