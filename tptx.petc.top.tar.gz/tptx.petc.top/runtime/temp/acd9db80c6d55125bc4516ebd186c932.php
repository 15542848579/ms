<?php if (!defined('THINK_PATH')) exit(); /*a:3:{s:81:"D:\phpStudy\PHPTutorial\WWW\gg\public/../application/index\view\yewu\huiyuan.html";i:1543250408;s:69:"D:\phpStudy\PHPTutorial\WWW\gg\application\index\view\common\top.html";i:1543079499;s:72:"D:\phpStudy\PHPTutorial\WWW\gg\application\index\view\common\bottom.html";i:1543049873;}*/ ?>
<!DOCTYPE html>
<html class="pixel-ratio-1" lang="zh-cmn-Hans"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1,minimum-scale=1,maximum-scale=1,user-scalable=no,viewport-fit=cover">
    <title>微广告</title>
    <link rel="stylesheet" href="/index/common/weui.css"><!--官方css-->
    <link rel="stylesheet" href="/index/common/jquery-weui.css"><!--弹出窗口用到这个-->
    <link rel="stylesheet" type="text/css" href="/index/common/banner.css">
    <link rel="stylesheet" href="/index/common/example.css">
    <link rel="stylesheet" type="text/css" href="/index/common/mystyle2.css">

    <script src="/index/common/jquery-2.js"></script>
    <script src="/index/common/jquery-weui.js"></script><!--弹出窗口用到这个-->
    <script src="/index/common/myjs3.js"></script>
</head>
<body>
<script>
function plusReady(){
// 隐藏滚动条
plus.webview.currentWebview().setStyle({scrollIndicator:'none'});
// Android处理返回键
plus.key.addEventListener('backbutton',function(){
window.history.go(-1);
},false);
}
if(window.plus){
plusReady();
}else{
document.addEventListener('plusready',plusReady,false);
}
</script>

<div id="mark_mask" style="display:none;position:fixed;top:40px;left:0;z-index:99999999;height:1000px;width:100%;background:rgba(0,0,0,0.4);"></div>
<div class="head">
    <div class="public_back my_back"><img src="/index/common/left.png" align="absmiddle"></div>
    <div class="head_title">微广告</div>
    <div style="clear: both"></div>
</div>
<div class="container"><div class="page">


    <div class="head_copy">&nbsp;</div>

    <div class="temp_reg"><img src="/index/common/5beccd53aabb8.jpg" alt="" style="width: 100%;"></div>
    <script>
        $('.temp_reg img').css('width','100%');
    </script>

    <form action="/index/yewu/dohuiyuan" method="post">
    <div class="weui-cells__title" style="font-size: 16px;">级别</div>
    <div class="weui-cells weui-cells_radio">
        <label class="weui-cell weui-check__label">
            <div class="weui-cell__bd">
                <p>99元(初级)</p>
            </div>
            <div class="weui-cell__ft">
                <input type="radio" class="weui-check" name="buyUser" value="1" checked="checked">
                <span class="weui-icon-checked"></span>
            </div>
        </label>
        <label class="weui-cell weui-check__label">
            <div class="weui-cell__bd">
                <p>999元(高级)</p>
            </div>
            <div class="weui-cell__ft">
                <input type="radio" name="buyUser" class="weui-check" value="2">
                <span class="weui-icon-checked"></span>
            </div>
        </label>
    </div>

    <div class="weui-cells__title" style="font-size: 16px;">支付方式</div>

    <div class="weui-cells weui-cells_radio">
        <label class="weui-cell weui-check__label">
            <div class="weui-cell__bd">
                <p>支付宝</p>
            </div>
            <div class="weui-cell__ft">
                <input type="radio" class="weui-check" name="payStyle" value="1" checked="checked">
                <span class="weui-icon-checked"></span>
            </div>
        </label>
        <label class="weui-cell weui-check__label">
            <div class="weui-cell__bd">
                <p>银行卡</p>
            </div>
            <div class="weui-cell__ft">
                <input type="radio" name="payStyle" class="weui-check" value="2">
                <span class="weui-icon-checked"></span>
            </div>
        </label>
        <label class="weui-cell weui-check__label">
            <div class="weui-cell__bd">
                <p>余额支付(您的余额:<?php echo $list['sy']; ?>元)</p>
            </div>
            <div class="weui-cell__ft">
                <input type="radio" name="payStyle" class="weui-check" value="3">
                <span class="weui-icon-checked"></span>
            </div>
        </label>

    </div>



    <div class="page__bd page__bd_spacing"  style="margin-top: 10px;margin-bottom: 30px">
        <input type="submit" value="确定" class="weui-btn weui-btn_primary">
    </div>
</form>

</div></div>
﻿<script src="/index/common/immersed.js"></script>
<style>
    .container{overflow: auto;}
</style>
</body>
</html>