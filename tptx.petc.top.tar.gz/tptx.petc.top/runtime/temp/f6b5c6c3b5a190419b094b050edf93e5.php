<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:90:"C:\phpStudy\PHPTutorial\WWW\tptx\public/../application/admin\view\index\addshopinsert.html";i:1543995206;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <title>添加公告</title>
    <link rel="stylesheet" href="../frame/layui/css/layui.css">
    <link rel="stylesheet" href="../frame/static/css/style.css">
    <link rel="icon" href="../frame/static/image/code.png">
</head>
<body class="body">

<form class="layui-form layui-form-pane layui-row" method="post" action="/admin/index/donotice1">
    <div class="layui-form-item">
        <label class="layui-form-label">广告标题</label>

        <div class="layui-input-block">
            <input type="text" name="title" autocomplete="off" placeholder="请输入标题" lay-verify="required"
                   class="layui-input">
        </div>
    </div>
    <div class="layui-form-item">
        <label class="layui-form-label layui-col-xs12">广告内容</label>
        <div class="layui-input-block">
            <textarea placeholder="请输入内容" name="body" class="layui-textarea"></textarea>
        </div>
    </div>
     <div class="layui-form-item">
        <label class="layui-form-label">数量</label>

        <div class="layui-input-block">
            <input type="text" name="sl" autocomplete="off" placeholder="请输入数量" lay-verify="required"
                   class="layui-input">
        </div>
    </div>
    <div class="layui-form-item">
        <label class="layui-form-label">发布人</label>

        <div class="layui-input-block">
            <input type="text" name="fb" autocomplete="off" placeholder="请输入发布人" lay-verify="required"
                   class="layui-input">
        </div>
    </div>
    <div class="layui-form-item">
        <label class="layui-form-label">发布金额</label>

        <div class="layui-input-block">
            <input type="text" name="price" autocomplete="off" placeholder="请输入一单金额" lay-verify="required"
                   class="layui-input">
        </div>
    </div>
    <div class="layui-form-item">
        <label class="layui-form-label">任务等级选择</label>
        <div class="layui-input-block">
            <select lay-filter="mining" name="ggdj">
                <option disabled selected>请选择</option>
                <option value="0">游客任务</option>
                <option value="1">会员任务</option>
                <option value="2">高级任务</option>
            </select>
        </div>
    </div>
    <div class="layui-form-item">
        会员任务可设定为任意金额，高级会员任务已被固定为4
    </div>
    <div class="layui-upload" style="margin-left:110px;">
        <button type="button" class="layui-btn" id="test1">上传图片</button>
        <div class="layui-upload-list">
            <img class="layui-upload-img" id="demo1" height="300px" width="300px">
            <p id="demoText"></p>
        </div>
    </div>
    <input type="hidden" name="image" value="" id="image">

    <div class="layui-upload" style="margin-left:110px;">
        <button type="button" class="layui-btn" id="test2">上传图片</button>
        <div class="layui-upload-list">
            <img class="layui-upload-img" id="demo2" height="300px" width="300px">
            <p id="demoText"></p>
        </div>
    </div>
    <input type="hidden" name="image2" value="" id="image2">


    <div class="form-foot">
        <div class="layui-input-inline">
            <button type="submit" class="layui-btn" lay-submit="" lay-filter="check" id="ContentPlaceHolder1_Button1">
                <i class="layui-icon">&#xe608;</i>提交
            </button>
        </div>
        <div class="layui-input-inline">
            <button type="reset" class="layui-btn layui-btn-primary">
                <i class="layui-icon">&#xe63f;</i>重置
            </button>
        </div>
    </div>
</form>
<script src="../frame/layui/layui.js" charset="utf-8"></script>
 <script>
        layui.use(['upload','form','laydate'], function() { //upload 文件上传
            var form = layui.form
                ,layer = layui.layer
                ,layedit = layui.layedit
                ,laydate = layui.laydate;
            var $ = layui.jquery
                ,upload = layui.upload; //文件上传
 
            laydate.render({
                elem: '#date1'
            });
 
            //普通图片上传
            var uploadInst = upload.render({
                elem: '#test1'
                , url: '<?php echo url("/admin/index/upload"); ?>'
                , before: function (obj) {
                    //预读本地文件示例，不支持ie8
                    obj.preview(function (index, file, result) {
//                        alert(result);
                        $('#demo1').attr('src', result); //图片链接（base64）
                    });
                }
                , done: function (res) {
                    //如果上传失败
                    if (res.code == 0) {
                        return layer.msg('上传失败');
                    }
                    //上传成功
                    console.log(res);
                    document.getElementById("image").value=res['savename'];
                }
                , error: function () {
                    //演示失败状态，并实现重传
                    var demoText = $('#demoText');
                    demoText.html('<span style="color: #FF5722;">上传失败</span> <a class="layui-btn layui-btn-xs demo-reload">重试</a>');
                    demoText.find('.demo-reload').on('click', function () {
                        uploadInst.upload();
                    });
                }
            });
 
            //监听提交
            form.on('submit(demo1)', function(data){
                layer.alert(JSON.stringify(data.field), {
                    title: '最终的提交信息'
                })
                return false;
            });
 
        });
 
    </script>
    <script>
        layui.use(['upload','form','laydate'], function() { //upload 文件上传
            var form = layui.form
                ,layer = layui.layer
                ,layedit = layui.layedit
                ,laydate = layui.laydate;
            var $ = layui.jquery
                ,upload = layui.upload; //文件上传
 
            laydate.render({
                elem: '#date1'
            });
 
            //普通图片上传
            var uploadInst = upload.render({
                elem: '#test2'
                , url: '<?php echo url("/admin/index/upload"); ?>'
                , before: function (obj) {
                    //预读本地文件示例，不支持ie8
                    obj.preview(function (index, file, result) {
//                        alert(result);
                        $('#demo2').attr('src', result); //图片链接（base64）
                    });
                }
                , done: function (res) {
                    //如果上传失败
                    if (res.code == 0) {
                        return layer.msg('上传失败');
                    }
                    //上传成功
                    console.log(res);
                    document.getElementById("image2").value=res['savename'];
                }
                , error: function () {
                    //演示失败状态，并实现重传
                    var demoText = $('#demoText');
                    demoText.html('<span style="color: #FF5722;">上传失败</span> <a class="layui-btn layui-btn-xs demo-reload">重试</a>');
                    demoText.find('.demo-reload').on('click', function () {
                        uploadInst.upload();
                    });
                }
            });
 
            //监听提交
            form.on('submit(demo2)', function(data){
                layer.alert(JSON.stringify(data.field), {
                    title: '最终的提交信息'
                })
                return false;
            });
 
        });
 
    </script>
</body>
</html>