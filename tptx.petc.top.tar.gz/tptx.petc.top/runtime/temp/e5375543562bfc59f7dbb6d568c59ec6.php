<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:78:"/www/wwwroot/7.ccooffee/tptx/public/../application/index/view/login/zhuce.html";i:1543992560;}*/ ?>
<!DOCTYPE html>
<html class="pixel-ratio-1" lang="zh-cmn-Hans"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">


    <meta name="viewport" content="width=device-width,initial-scale=1,minimum-scale=1,maximum-scale=1,user-scalable=no,viewport-fit=cover">
    <title>微客天下</title>
    <link rel="stylesheet" href="/index/common/weui.css">
    <link rel="stylesheet" href="/index/common/jquery-weui.css">

    <link rel="stylesheet" type="text/css" href="/index/common/banner.css">
    <link rel="stylesheet" href="/index/common/example.css">
    <link rel="stylesheet" type="text/css" href="/index/common/mystyle2.css">
    <script src="/index/common/jquery-2.js"></script>
    <script src="/index/common/myjs3.js"></script>
</head>
<body>
<style type="text/css">
    .button {
    background-color: #4CAF50; /* Green */
    border: none;
    color: white;
    padding: 15px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
}
</style>
<script>
function plusReady(){
// 隐藏滚动条
plus.webview.currentWebview().setStyle({scrollIndicator:'none'});
// Android处理返回键
plus.key.addEventListener('backbutton',function(){
window.history.go(-1);
},false);
}
if(window.plus){
plusReady();
}else{
document.addEventListener('plusready',plusReady,false);
}


</script><div id="mark_mask" style="display:none;position:fixed;top:40px;left:0;z-index:99999999;height:1000px;width:100%;background:rgba(0,0,0,0.4);"></div>
<div class="container"><div class="page">
    <article class="weui-article">
        <div class="logodiv"><img src="/index/common/logo.png"></div>
        <!--<h1>微广告注册</h1>-->
    </article>

    <form action="/index/login/reg" method="post">
            <input type="hidden" name="tjr" class="weui-input" placeholder="推荐人手机号码" value="<?php echo $mobile; ?>">
        <div class="weui-cell">
            <input type="text" name="username" class="weui-input" placeholder="请输入账号,由数字字母组成">
        </div>
        <div class="weui-cell">
            <input type="text" name="name" class="weui-input" placeholder="请输入真实姓名">
        </div>
        <div class="weui-cell">
            <input type="text" name="mobile" id="mobile" class="weui-input" placeholder="请输入手机号">
        </div>

        <div class="weui-cell">
            <input type="password" class="weui-input" name="password" placeholder="请输入密码">
        </div>
        <div class="weui-cell">
            <input type="password" class="weui-input" name="password1" placeholder="请重复输入密码">
        </div>

        <div class="weui-cell">

            <div class="weui-cell__bd">
                <input type="text" class="weui-input" id="txtyzm" name="code" placeholder="验证码">
            </div>
            <div class="weui-cell__ft">
                <input type="button" class="button" onclick="time(this)"  id="gettxyzmb" value="点击获取">
            </div>
        </div>
    <div style="clear: both;height:10px;"></div>
    <div class="page__bd page__bd_spacing">
    <input type="submit" value="确定" class="weui-btn  weui-btn_primary">
    <a href="/index/login/index" class="weui-btn weui-btn_primary">返回登陆</a>
    </div>
    </form>

</div>
</div>

<script>
       function time(o) {

            if ($("#mobile").val() == "") {
                alert("请填写手机号");
                return false;
            }

            if (!isMobile($("#mobile").val())) {
                alert("手机格式不正确");
                return false;
            }

            var tel = $('#mobile').val();
            s = $.ajax({ url: "/index/login/sms/phone/" + tel  });
            yzm = s.responseText;
            sjh = tel;
            okssss(o);
        }
        var wait = 60;
        function okssss(o) {
            if (wait == 0) {
                $(o).removeAttr("disabled");
                $(o).val("免费获取验证码");
                wait = 120;
            } else {
                $(o).attr("disabled", true);
                $(o).val("重新发送(" + wait + ")");
                wait--;
                setTimeout(function () {
                    okssss(o);
                },
            1000);
            }
        }

        function isMobile(str) {
            var myreg = /^([0]?)(((13[0-9]{1})|(14[0-9]{1})|(15[0-9]{1})|(16[0-9]{1})|(17[0-9]{1})|(18[0-9]{1})|(19[0-9]{1}))+\d{8})$/;
            return myreg.test(str);
        }
</script>

<style>
    .logodiv{text-align: center;}
    .logodiv img{width: 100px;}
    h1{text-align: center;color: gray;}
</style>
﻿<script src="/index/common/immersed.js"></script>
<style>
    .container{overflow: auto;}
</style>

</body></html>