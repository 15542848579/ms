<?php if (!defined('THINK_PATH')) exit(); /*a:3:{s:78:"D:\phpStudy\PHPTutorial\WWW\gg\public/../application/index\view\renwu\log.html";i:1543171628;s:69:"D:\phpStudy\PHPTutorial\WWW\gg\application\index\view\common\top.html";i:1543079499;s:72:"D:\phpStudy\PHPTutorial\WWW\gg\application\index\view\common\bottom.html";i:1543049873;}*/ ?>
<!DOCTYPE html>
<html class="pixel-ratio-1" lang="zh-cmn-Hans"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1,minimum-scale=1,maximum-scale=1,user-scalable=no,viewport-fit=cover">
    <title>微广告</title>
    <link rel="stylesheet" href="/index/common/weui.css"><!--官方css-->
    <link rel="stylesheet" href="/index/common/jquery-weui.css"><!--弹出窗口用到这个-->
    <link rel="stylesheet" type="text/css" href="/index/common/banner.css">
    <link rel="stylesheet" href="/index/common/example.css">
    <link rel="stylesheet" type="text/css" href="/index/common/mystyle2.css">

    <script src="/index/common/jquery-2.js"></script>
    <script src="/index/common/jquery-weui.js"></script><!--弹出窗口用到这个-->
    <script src="/index/common/myjs3.js"></script>
</head>
<body>
<script>
function plusReady(){
// 隐藏滚动条
plus.webview.currentWebview().setStyle({scrollIndicator:'none'});
// Android处理返回键
plus.key.addEventListener('backbutton',function(){
window.history.go(-1);
},false);
}
if(window.plus){
plusReady();
}else{
document.addEventListener('plusready',plusReady,false);
}
</script>

<div id="mark_mask" style="display:none;position:fixed;top:40px;left:0;z-index:99999999;height:1000px;width:100%;background:rgba(0,0,0,0.4);"></div>
﻿<div class="head">
    <div class="public_back my_back"><img src="/index/common/left.png" align="absmiddle"></div>
    <div class="head_title">任务日志</div>
    <div style="clear: both"></div>
</div>

<div class="container"><div class="page">

    <div class="head_copy">&nbsp;</div>
    <?php if(is_array($list) || $list instanceof \think\Collection || $list instanceof \think\Paginator): $i = 0; $__LIST__ = $list;if( count($__LIST__)==0 ) : echo "没有记录" ;else: foreach($__LIST__ as $key=>$row): $mod = ($i % 2 );++$i;?>
    <a class="weui-media-box weui-media-box_appmsg weui-cell weui-cell_access">
        <div class="weui-media-box__bd">
            <h4 class="weui-media-box__title"></h4>
            <p class="weui-media-box__desc" style="line-height: 20px;">广告名:<?php echo $row['title']; ?></p>
            <p class="weui-media-box__desc" style="line-height: 20px;">状态:<span style="color:red">
            	<?php switch($row['type']): case "1": ?>已提交<?php break; case "2": ?>已发放<?php break; case "3": ?>不合格<?php break; endswitch; ?>
            </span></p>
            <p class="weui-media-box__desc" style="line-height: 20px;">提交时间:<?php echo date('Y-m-d H:i:s',$row['ttime']); ?></p>

        </div>
        <div class="weui-media-box__hd" style="width: 100px;">
            <?php echo $row['price']; ?>元
        </div>
        <span class="weui-cell__ft"></span>
    </a>
    <?php endforeach; endif; else: echo "没有记录" ;endif; ?>
    <div class="weui-footer" style="background: #ffffff;padding: 15px;">
    <?php echo $page; ?>
	</div>
</div></div>
﻿<script src="/index/common/immersed.js"></script>
<style>
    .container{overflow: auto;}
</style>
</body>
</html>